//
//  Chapter4HeadingTrackingViewController.m
//  Chapter4HeadingTracking

#import "Chapter4HeadingTrackingViewController.h"

@implementation Chapter4HeadingTrackingViewController
@synthesize labelHeading;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setLabelHeading:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    if(error.code==kCLErrorDenied){
        [manager stopUpdatingHeading];
        self.labelHeading.text=@"ERROR: Heading tracking is denied";
    }
}
-(void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading{
    NSDate *headingDate=newHeading.timestamp;
    NSTimeInterval headingInterval=[headingDate timeIntervalSinceNow];
    if(abs(headingInterval)<30){
        if(newHeading.headingAccuracy<0)
            return;
        
        self.labelHeading.text=[NSString stringWithFormat:@"Your new heading is: %.1f°", newHeading.magneticHeading];
    }
}
-(BOOL)locationManagerShouldDisplayHeadingCalibration:(CLLocationManager *)manager
{
    return YES;
}  
- (IBAction)switchHeadingServices:(id)sender {
    if([CLLocationManager headingAvailable]){
        if([sender isKindOfClass:[UISwitch class]]){
            UISwitch *headingSwitch=(UISwitch *)sender;
            if(headingSwitch.on){
                if(_locationManager==nil){
                    _locationManager=[[CLLocationManager alloc] init];
                    _locationManager.headingFilter=5;
                    _locationManager.purpose=@"We will use your location to tell you where you are headed";
                    _locationManager.delegate=self;
                }
                [_locationManager startUpdatingHeading];
                self.labelHeading.text=@"Starting heading tracking...";
            }else{
                self.labelHeading.text=@"Turned heading tracking off";
                if(_locationManager!=nil){
                    [_locationManager stopUpdatingHeading];
                }
            }
        }
    }else{
        self.labelHeading.text=@"Heading services unavailable";
    }
}
@end
