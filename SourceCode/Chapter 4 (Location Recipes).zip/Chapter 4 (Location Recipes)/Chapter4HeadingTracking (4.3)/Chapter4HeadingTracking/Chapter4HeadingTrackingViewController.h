//
//  Chapter4HeadingTrackingViewController.h
//  Chapter4HeadingTracking

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface Chapter4HeadingTrackingViewController : UIViewController <CLLocationManagerDelegate>{
    CLLocationManager *_locationManager;
    UILabel *labelHeading;
}

@property (strong, nonatomic) IBOutlet UILabel *labelHeading;
- (IBAction)switchHeadingServices:(id)sender;
@end
