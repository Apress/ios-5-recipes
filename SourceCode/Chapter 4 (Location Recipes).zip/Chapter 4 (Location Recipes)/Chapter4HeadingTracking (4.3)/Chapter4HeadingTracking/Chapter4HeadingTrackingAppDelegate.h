//
//  Chapter4HeadingTrackingAppDelegate.h
//  Chapter4HeadingTracking

#import <UIKit/UIKit.h>

@class Chapter4HeadingTrackingViewController;

@interface Chapter4HeadingTrackingAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Chapter4HeadingTrackingViewController *viewController;

@end
