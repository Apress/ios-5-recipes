//
//  main.m
//  Chapter4HeadingTracking

#import <UIKit/UIKit.h>

#import "Chapter4HeadingTrackingAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Chapter4HeadingTrackingAppDelegate class]));
    }
}
