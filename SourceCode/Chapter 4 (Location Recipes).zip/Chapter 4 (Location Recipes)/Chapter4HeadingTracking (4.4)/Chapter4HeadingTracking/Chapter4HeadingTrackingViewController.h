//
//  Chapter4HeadingTrackingViewController.h
//  Chapter4HeadingTracking

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface Chapter4HeadingTrackingViewController : UIViewController <CLLocationManagerDelegate>{
    CLLocationManager *_locationManager;
    UILabel *labelHeading;
    UILabel *labelTrueHeading;
}


@property (strong, nonatomic) IBOutlet UILabel *labelHeading;
@property (strong, nonatomic) IBOutlet UILabel *labelTrueHeading;
- (IBAction)switchHeadingServices:(id)sender;
@end
