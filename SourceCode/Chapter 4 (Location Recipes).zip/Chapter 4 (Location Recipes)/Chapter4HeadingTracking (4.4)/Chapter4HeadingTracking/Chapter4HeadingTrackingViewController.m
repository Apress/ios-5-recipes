//
//  Chapter4HeadingTrackingViewController.m
//  Chapter4HeadingTracking

#import "Chapter4HeadingTrackingViewController.h"

@implementation Chapter4HeadingTrackingViewController
@synthesize labelHeading;
@synthesize labelTrueHeading;
- (IBAction)switchHeadingServices:(id)sender {
    if([CLLocationManager headingAvailable]){
        if([sender isKindOfClass:[UISwitch class]]){
            UISwitch *headingSwitch=(UISwitch *)sender;
            if(headingSwitch.on){
                if(_locationManager==nil){
                    _locationManager=[[CLLocationManager alloc] init];
                    _locationManager.headingFilter=5;
                    _locationManager.purpose=@"We will use your location to tell you where you are headed";
                    _locationManager.delegate=self;
                }
                [_locationManager startUpdatingHeading];
                [_locationManager startUpdatingLocation];
                self.labelHeading.text=@"Starting heading tracking...";
            }else{
                self.labelHeading.text=@"Turned heading tracking off";
                if(_locationManager!=nil){
                    [_locationManager stopUpdatingHeading];
                    [_locationManager stopUpdatingLocation];
                }
            }
        }
    }else{
        self.labelHeading.text=@"Heading services unavailable";
    }
}

-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    if(error.code==kCLErrorDenied){
        [manager stopUpdatingHeading];
        self.labelHeading.text=@"ERROR: Heading tracking is denied";
    }
}

-(void)locationManager:(CLLocationManager *)manager didUpdateHeading:(CLHeading *)newHeading{
    NSDate *headingDate=newHeading.timestamp;
    NSTimeInterval headingInterval=[headingDate timeIntervalSinceNow];
    if(abs(headingInterval)<30){
        if(newHeading.headingAccuracy<0)
            return;
        
        if(newHeading.trueHeading>=0){
            self.labelTrueHeading.text=[NSString stringWithFormat:@"Your true heading is: %.1f°", newHeading.trueHeading];
        }
        
        self.labelHeading.text=[NSString stringWithFormat:@"Your magnetic heading is: %.1f°", newHeading.magneticHeading];
    }
}

-(BOOL)locationManagerShouldDisplayHeadingCalibration:(CLLocationManager *)manager{
    return YES;
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setLabelHeading:nil];
    [self setLabelTrueHeading:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
@end
