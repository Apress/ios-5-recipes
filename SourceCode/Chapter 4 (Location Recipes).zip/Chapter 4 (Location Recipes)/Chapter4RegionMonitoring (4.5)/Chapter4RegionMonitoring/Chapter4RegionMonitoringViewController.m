//
//  Chapter4RegionMonitoringViewController.m
//  Chapter4RegionMonitoring

#import "Chapter4RegionMonitoringViewController.h"

@implementation Chapter4RegionMonitoringViewController
@synthesize labelRegionInfo;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setLabelRegionInfo:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
-(void)locationManager:(CLLocationManager *)manager monitoringDidFailForRegion:(CLRegion *)region withError:(NSError *)error{
    switch (error.code) {
        case kCLErrorRegionMonitoringDenied:
        {
            self.labelRegionInfo.text=@"Region monitoring is denied on this device";
            break;
        }   
        case kCLErrorRegionMonitoringFailure:
        {
            self.labelRegionInfo.text=[NSString stringWithFormat:@"Region monitoring failed for region: %@", region.identifier];
            break;
        }
        default:
        {
            self.labelRegionInfo.text=[NSString stringWithFormat:@"An unhandled error occured: %@", error.description];
            break;
        }
    }
}
-(void)locationManager:(CLLocationManager *)manager didEnterRegion:(CLRegion *)region{
    self.labelRegionInfo.text = @"Welcome to Baltimore!";
    UILocalNotification *locationNotification = [[UILocalNotification alloc] init];
    locationNotification.alertBody=@"Welcome to Baltimore!";
    locationNotification.alertAction=@"Ok";
    locationNotification.soundName = UILocalNotificationDefaultSoundName;
    [[UIApplication sharedApplication] presentLocalNotificationNow:locationNotification];
}
-(void)locationManager:(CLLocationManager *)manager didExitRegion:(CLRegion *)region{
    self.labelRegionInfo.text = @"Thanks for visiting Baltimore! Come back soon!";
    UILocalNotification *locationNotification = [[UILocalNotification alloc] init];
    locationNotification.alertBody=@"Thanks for visiting Baltimore! Come back soon!";
    locationNotification.alertAction=@"Ok";
    locationNotification.soundName = UILocalNotificationDefaultSoundName;
    [[UIApplication sharedApplication] presentLocalNotificationNow:locationNotification];
    
}
- (IBAction)regionMonitoringToggle:(id)sender 
{
    if([CLLocationManager regionMonitoringAvailable] && [CLLocationManager regionMonitoringEnabled]){
        //Make sure sender is UISwitch
        if([sender isKindOfClass:[UISwitch class]])
        {
            UISwitch *regionSwitch=(UISwitch *) sender;
            //If UISwitch is turned On
            if(regionSwitch.on)
            {
                if(_locationManager==nil)
                {
                    _locationManager=[[CLLocationManager alloc] init];
                    _locationManager.purpose=@"To welcome you to Baltimore";
                    _locationManager.delegate=self;
                }
                CLLocationCoordinate2D baltimoreCoordinate=CLLocationCoordinate2DMake(39.2963, -76.613);
                int regionRadius=3000;
                if(regionRadius>_locationManager.maximumRegionMonitoringDistance)
                {
                    regionRadius=_locationManager.maximumRegionMonitoringDistance;
                }
                CLRegion *baltimoreRegion=[[CLRegion alloc] initCircularRegionWithCenter:baltimoreCoordinate radius:regionRadius identifier:@"baltimoreRegion"];
                [_locationManager startMonitoringForRegion:baltimoreRegion      
                                           desiredAccuracy:kCLLocationAccuracyHundredMeters];
            }
            else
            {
                //If UISwitch is turned Off
                if(_locationManager!=nil)
                {
                    for (CLRegion *monitoredRegion in [_locationManager monitoredRegions]) 
                    {
                        [_locationManager stopMonitoringForRegion:monitoredRegion];
                        self.labelRegionInfo.text=[NSString stringWithFormat:@"Turned off region monitoring fore : %@", monitoredRegion.identifier];
                    }
                }
            }
        }
    }
}
@end
