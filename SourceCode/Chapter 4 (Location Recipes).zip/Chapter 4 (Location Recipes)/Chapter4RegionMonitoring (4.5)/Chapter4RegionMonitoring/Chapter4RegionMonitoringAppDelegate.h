//
//  Chapter4RegionMonitoringAppDelegate.h
//  Chapter4RegionMonitoring

#import <UIKit/UIKit.h>

@class Chapter4RegionMonitoringViewController;

@interface Chapter4RegionMonitoringAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Chapter4RegionMonitoringViewController *viewController;

@end
