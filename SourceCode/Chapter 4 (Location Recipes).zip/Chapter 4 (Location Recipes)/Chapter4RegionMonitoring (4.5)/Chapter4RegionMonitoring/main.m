//
//  main.m
//  Chapter4RegionMonitoring

#import <UIKit/UIKit.h>

#import "Chapter4RegionMonitoringAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Chapter4RegionMonitoringAppDelegate class]));
    }
}
