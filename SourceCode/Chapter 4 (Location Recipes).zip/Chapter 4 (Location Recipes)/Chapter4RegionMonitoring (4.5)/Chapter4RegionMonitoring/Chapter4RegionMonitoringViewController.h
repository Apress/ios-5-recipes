//
//  Chapter4RegionMonitoringViewController.h
//  Chapter4RegionMonitoring

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface Chapter4RegionMonitoringViewController : UIViewController <CLLocationManagerDelegate>{
    CLLocationManager *_locationManager;
    UILabel *labelRegionInfo;
}

@property (strong, nonatomic) IBOutlet UILabel *labelRegionInfo;
- (IBAction)regionMonitoringToggle:(id)sender;

@end
