//
//  Chapter4SignificantLocationTrackerAppDelegate.h
//  Chapter4SignificantLocationTracker

#import <UIKit/UIKit.h>

@class Chapter4SignificantLocationTrackerViewController;

@interface Chapter4SignificantLocationTrackerAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Chapter4SignificantLocationTrackerViewController *viewController;

@end
