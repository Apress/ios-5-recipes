//
//  Chapter4SignificantLocationTrackerViewController.h
//  Chapter4SignificantLocationTracker

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface Chapter4SignificantLocationTrackerViewController : UIViewController <CLLocationManagerDelegate>{
    CLLocationManager *_locationManager;
    UILabel *labelLocation;
}
@property (strong, nonatomic) IBOutlet UILabel *labelLocation;
- (IBAction)toggleLocationServices:(id)sender;

@end
