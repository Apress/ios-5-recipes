//
//  Chapter4SignificantLocationTrackerViewController.m
//  Chapter4SignificantLocationTracker

#import "Chapter4SignificantLocationTrackerViewController.h"

@implementation Chapter4SignificantLocationTrackerViewController
@synthesize labelLocation;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
    NSDate *eventDate=newLocation.timestamp;
    NSTimeInterval eventInterval = [eventDate timeIntervalSinceNow];
    NSLog(@"Event Interval: %f", eventInterval);
    NSLog(@"Accuracy: %f", newLocation.horizontalAccuracy);
    if(abs(eventInterval)<30.0){
        if(newLocation.horizontalAccuracy>=0){
            self.labelLocation.text = newLocation.description;
            UILocalNotification *locationNotification = [[UILocalNotification alloc] init];
            locationNotification.alertBody=[NSString stringWithFormat:@"New Location: %.3f, %.3f", newLocation.coordinate.latitude, newLocation.coordinate.longitude];
            locationNotification.alertAction=@"Ok";
            locationNotification.soundName = UILocalNotificationDefaultSoundName;
            //Increment the applicationIconBadgeNumber
            locationNotification.applicationIconBadgeNumber=[[UIApplication sharedApplication] applicationIconBadgeNumber]+1;
            [[UIApplication sharedApplication] presentLocalNotificationNow:locationNotification];
        }
    }
}
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    if(error.code==kCLErrorDenied){
        [manager stopMonitoringSignificantLocationChanges];
    }
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setLabelLocation:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)toggleLocationServices:(id)sender {
    //Check if location services are enabled
    if(![CLLocationManager locationServicesEnabled]){
        UIAlertView *alertLocation = [[UIAlertView alloc] initWithTitle:@"Location Services Needed" message:@"Location services are needed to make this app functional" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil];
        [alertLocation show];
        return;
    }
    
    //Future proof, make sure sender is UISwitch
    if([sender isKindOfClass:[UISwitch class]]){
        UISwitch *locationSwitch=(UISwitch *)sender;
        if(locationSwitch.on){
            //Check if _locationManager has been instantiated
            if(_locationManager==nil){
                //Instantiate _locationManager
                _locationManager = [[CLLocationManager alloc] init];
                _locationManager.purpose=@"We will only use your location locally.  We will not record it or send it to anyone";
                _locationManager.delegate=self;
            }
            //Start updating location changes
            [_locationManager startMonitoringSignificantLocationChanges];
        }else{
            if(_locationManager!=nil){
                //Stop monitoring for location changes
                [_locationManager stopMonitoringSignificantLocationChanges];
            }
        }
    }
}
@end
