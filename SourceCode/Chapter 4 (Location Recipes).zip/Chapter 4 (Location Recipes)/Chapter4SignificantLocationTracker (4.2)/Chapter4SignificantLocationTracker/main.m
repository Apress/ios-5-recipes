//
//  main.m
//  Chapter4SignificantLocationTracker

#import <UIKit/UIKit.h>

#import "Chapter4SignificantLocationTrackerAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Chapter4SignificantLocationTrackerAppDelegate class]));
    }
}
