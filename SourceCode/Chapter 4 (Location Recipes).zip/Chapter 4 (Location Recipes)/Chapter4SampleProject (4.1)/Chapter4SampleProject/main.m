//
//  main.m
//  Chapter4SampleProject

#import <UIKit/UIKit.h>

#import "Chapter4SampleProjectAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Chapter4SampleProjectAppDelegate class]));
    }
}
