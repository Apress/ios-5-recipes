//
//  Chapter4SampleProjectViewController.m
//  Chapter4SampleProject
//

#import "Chapter4SampleProjectViewController.h"

@implementation Chapter4SampleProjectViewController
@synthesize labelLocation;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
    //Check to make sure this is a recent location event
    NSDate *eventDate=newLocation.timestamp;
    NSTimeInterval eventInterval=[eventDate timeIntervalSinceNow];
    if(abs(eventInterval)<30.0){
        //Check to make sure the event is accurate
        if(newLocation.horizontalAccuracy>=0 && newLocation.horizontalAccuracy<20){
            self.labelLocation.text=newLocation.description;
        }
    }
}
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    if(error.code == kCLErrorDenied){
        [manager stopUpdatingLocation];
    }
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setLabelLocation:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)toggleLocationServices:(id)sender {
    //Display an UIAlertView if locationServices are not enabled and return
    if(![CLLocationManager locationServicesEnabled]){
        UIAlertView *alertLocation = [[UIAlertView alloc] initWithTitle:@"Location Error" message:@"Location services must be enabled for this feature to work" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alertLocation show];
        return;
    }
    
    //Future Proof: Make sure it's a UISwitch calling this action
    if([sender isKindOfClass:[UISwitch class]]){
        UISwitch *locationSwitch=(UISwitch *)sender;
        //Check if switch is "on"
        if(locationSwitch.on){
            //Check if _locationManager has been instantiated yet
            if(_locationManager==nil){
                //Instantiate _locationManager
                _locationManager = [[CLLocationManager alloc] init];
                _locationManager.desiredAccuracy=kCLLocationAccuracyBest;
                _locationManager.distanceFilter=1;
                _locationManager.purpose=@"We will only use your location information to display your present location.  We will not send it or record it.";                
                _locationManager.delegate=self;
            }
            //Start updating location
            [_locationManager startUpdatingLocation];
        }else{
            //Check if _locationManager has been instantiated yet
            if(_locationManager!=nil){
                //Stop updating location
                [_locationManager stopUpdatingLocation];
            }
        }
    }
}
@end
