//
//  Chapter4SampleProjectAppDelegate.h
//  Chapter4SampleProject
//


#import <UIKit/UIKit.h>

@class Chapter4SampleProjectViewController;

@interface Chapter4SampleProjectAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Chapter4SampleProjectViewController *viewController;

@end
