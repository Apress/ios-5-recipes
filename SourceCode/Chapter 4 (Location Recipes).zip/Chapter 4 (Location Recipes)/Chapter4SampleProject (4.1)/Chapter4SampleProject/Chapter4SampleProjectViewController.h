//
//  Chapter4SampleProjectViewController.h
//  Chapter4SampleProject
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
@interface Chapter4SampleProjectViewController : UIViewController <CLLocationManagerDelegate> {
    UILabel *labelLocation;
    CLLocationManager *_locationManager;
}
@property (strong, nonatomic) IBOutlet UILabel *labelLocation;
- (IBAction)toggleLocationServices:(id)sender;

@end
