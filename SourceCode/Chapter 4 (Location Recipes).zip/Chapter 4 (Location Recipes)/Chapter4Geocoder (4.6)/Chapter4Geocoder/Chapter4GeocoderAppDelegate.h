//
//  Chapter4GeocoderAppDelegate.h
//  Chapter4Geocoder

#import <UIKit/UIKit.h>

@class Chapter4GeocoderViewController;

@interface Chapter4GeocoderAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) Chapter4GeocoderViewController *viewController;

@end
