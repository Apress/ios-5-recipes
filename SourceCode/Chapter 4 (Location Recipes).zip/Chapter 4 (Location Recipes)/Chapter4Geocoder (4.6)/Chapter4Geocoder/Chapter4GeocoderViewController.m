//
//  Chapter4GeocoderViewController.m
//  Chapter4Geocoder

#import "Chapter4GeocoderViewController.h"

@implementation Chapter4GeocoderViewController
@synthesize labelGeocodeInfo;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setLabelGeocodeInfo:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
    NSDate *locationDate=newLocation.timestamp;
    NSTimeInterval locationInterval=[locationDate timeIntervalSinceNow];
    if(abs(locationInterval)<30){
        if(newLocation.horizontalAccuracy<0)
            return;
        
        //Instantiate _geoCoder if it has not been already
        if(_geoCoder==nil)
            _geoCoder=[[CLGeocoder alloc] init];
        
        //Only one geocoding instance per action 
        //so stop any previous geocoding actions before starting this one
        if([_geoCoder isGeocoding])
            [_geoCoder cancelGeocode];
        
        
        [_geoCoder reverseGeocodeLocation:newLocation 
                        completionHandler:^(NSArray* placemarks, NSError* error){
                            if([placemarks count]>0){
                                CLPlacemark *foundPlacemark=[placemarks objectAtIndex:0];
                                self.labelGeocodeInfo.text=[NSString stringWithFormat:@"You are in: %@", foundPlacemark.description];
                            }else if(error.code==kCLErrorGeocodeCanceled){
                                NSLog(@"Geocoding cancelled");
                            }else if(error.code==kCLErrorGeocodeFoundNoResult){
                                self.labelGeocodeInfo.text=@"No geocode result found";
                            }else if(error.code==kCLErrorGeocodeFoundPartialResult){
                                self.labelGeocodeInfo.text=@"Partial geocode result";
                            }else{
                                self.labelGeocodeInfo.text=[NSString stringWithFormat:@"Unknown error: %@", error.description];
                            }
                        }];
        
        //Stop updating location until they click the button again
        [manager stopUpdatingLocation];
    }
}
-(void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    if(error.code==kCLErrorDenied){
        self.labelGeocodeInfo.text=@"Location information denied";
    }
}
- (IBAction)actionWhereAmI:(id)sender {
    if([CLLocationManager locationServicesEnabled]){
        if([sender isKindOfClass:[UIButton class]]){
            if(_locationManager==nil){
                _locationManager=[[CLLocationManager alloc] init];
                _locationManager.purpose=@"To tell you where you are";
                _locationManager.delegate=self;
                _locationManager.distanceFilter=500;
                _locationManager.desiredAccuracy=kCLLocationAccuracyHundredMeters;
            }
            [_locationManager startUpdatingLocation];
            self.labelGeocodeInfo.text=@"Getting location...";
        }
    }else{
        self.labelGeocodeInfo.text=@"Location services are unavailable";
    }
}
@end
