//
//  main.m
//  Chapter4Geocoder

#import <UIKit/UIKit.h>

#import "Chapter4GeocoderAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Chapter4GeocoderAppDelegate class]));
    }
}
