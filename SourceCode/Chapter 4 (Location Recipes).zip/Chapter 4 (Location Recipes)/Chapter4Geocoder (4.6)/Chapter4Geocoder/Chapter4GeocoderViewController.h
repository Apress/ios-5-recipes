//
//  Chapter4GeocoderViewController.h
//  Chapter4Geocoder

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface Chapter4GeocoderViewController : UIViewController <CLLocationManagerDelegate>{
    CLLocationManager *_locationManager;
    CLGeocoder *_geoCoder;
    UILabel *labelGeocodeInfo;
}

@property (strong, nonatomic) IBOutlet UILabel *labelGeocodeInfo;
- (IBAction)actionWhereAmI:(id)sender;
@end
