//
//  MyDocument.h
//  iCloudTest

#import <Foundation/Foundation.h>

@interface MyDocument : UIDocument

@property (strong, nonatomic) NSString *userText;

@end
