//
//  iCloudStoreViewController.m
//  iCloudTest

#import "iCloudStoreViewController.h"
#define UBIQUITY_CONTAINER_URL @"12345ABCDE.com.domainName.iCloudTest"
//THIS PROJECT WILL NOT WORK CORRECTLY, AS IT MUST BE CONFIGURED TO YOUR OWN PROVISIONING PROFILE, APP ID, ICLOUD ACCOUNT, ETC. IT IS SIMPLY FOR THE CODE EXAMPLES.

@implementation iCloudStoreViewController
@synthesize textViewDisplay;
@synthesize document;
@synthesize metadataQuery, ubiquityURL;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
- (void)savePressed:(id)sender
{
    self.document.userText = self.textViewDisplay.text;
    [self.document saveToURL:self.ubiquityURL forSaveOperation:UIDocumentSaveForOverwriting completionHandler:^(BOOL success) 
    {
        if (success)
        {
           NSLog(@"Written to iCloud");
        } 
        else 
        {
           NSLog(@"Error writing to iCloud");
        }
    }];
}
- (void)metadataQueryDidFinishGathering: (NSNotification *)notification 
{
    NSMetadataQuery *query = [notification object];
    [query disableUpdates];
    
    [[NSNotificationCenter defaultCenter] 
     removeObserver:self 
     name:NSMetadataQueryDidFinishGatheringNotification 
     object:query];
    
    [query stopQuery];
    NSArray *results = [[NSArray alloc] initWithArray:[query results]];
    
    if ([results count] == 1)
    {
        ubiquityURL = [[results lastObject] valueForAttribute:NSMetadataItemURLKey];
        self.document = [[MyDocument alloc] initWithFileURL:ubiquityURL];
        
        [self.document openWithCompletionHandler:^(BOOL success) 
        {
             if (success)
             {
                 NSLog(@"Opened iCloud doc");
                 self.textViewDisplay.text = self.document.userText;
             } 
             else {
                 NSLog(@"Failed to open iCloud doc");
             }
         }];
    } 
    else 
    {
        self.document = [[MyDocument alloc] initWithFileURL:ubiquityURL];
        [self.document saveToURL:ubiquityURL forSaveOperation: UIDocumentSaveForCreating completionHandler:^(BOOL success) 
        {
              if (success)
              {
                  NSLog(@"File created and saved to iCloud");
              } 
              else 
              {
                  NSLog(@"Error, could not save file to iCloud");
              }
        }];
    } 
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
        
    NSFileManager *filemgr = [NSFileManager defaultManager];
    
    self.ubiquityURL = [[filemgr URLForUbiquityContainerIdentifier:UBIQUITY_CONTAINER_URL] URLByAppendingPathComponent:@"Documents"];
    
    if (self.ubiquityURL != nil)
    {
        if ([filemgr fileExistsAtPath:[self.ubiquityURL path]] == NO)
            [filemgr createDirectoryAtURL:self.ubiquityURL 
              withIntermediateDirectories:YES 
                               attributes:nil 
                                    error:nil];
        
        self.ubiquityURL = [self.ubiquityURL URLByAppendingPathComponent:@"document.doc"];
        
        self.metadataQuery = [[NSMetadataQuery alloc] init];
        [self.metadataQuery setPredicate:[NSPredicate 
                                     predicateWithFormat:@"%K like 'document.doc'", 
                                     NSMetadataItemFSNameKey]];
        [self.metadataQuery setSearchScopes:[NSArray 
                                        arrayWithObjects:NSMetadataQueryUbiquitousDocumentsScope,nil]];
        
        [[NSNotificationCenter defaultCenter] 
         addObserver:self 
         selector:@selector(metadataQueryDidFinishGathering:)
         name: NSMetadataQueryDidFinishGatheringNotification 
         object:metadataQuery];
        [self.metadataQuery startQuery];
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    self.textViewDisplay = nil;
    self.ubiquityURL = nil;
    self.document = nil;
    self.metadataQuery = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
