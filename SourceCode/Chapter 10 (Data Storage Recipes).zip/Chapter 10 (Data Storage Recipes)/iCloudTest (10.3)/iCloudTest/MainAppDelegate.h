//
//  MainAppDelegate.h
//  iCloudTest

#import <UIKit/UIKit.h>
#import "iCloudStoreViewController.h"

@class MainViewController;

@interface MainAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) iCloudStoreViewController *viewController;

@end
