//
//  HotspotInfoViewController.h
//  Hotspot

#import <UIKit/UIKit.h>
#import "Hotspot.h"

@class HotspotInfoViewController;

@protocol HotspotInfoDelegate <NSObject>
-(void)HotspotInfoViewController:(HotspotInfoViewController *)hotspotInfoVC didReturnHotspot:(Hotspot *)hotspot isNew:(BOOL)isNew;
@end

@interface HotspotInfoViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *textFieldName;
@property (strong, nonatomic) IBOutlet UITextField *textFieldAddress;
@property (strong, nonatomic) IBOutlet UITextField *textFieldCity;
@property (strong, nonatomic) IBOutlet UITextField *textFieldState;
- (IBAction)saveButtonPressed:(id)sender;

@property (strong, nonatomic) Hotspot *hotspot;

@property (strong, nonatomic) id <HotspotInfoDelegate> delegate;

@end
