//
//  Hotspot.h
//  Hotspot

#import <Foundation/Foundation.h>

@interface Hotspot : NSObject <NSCoding>

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *address;
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *state;

@end
