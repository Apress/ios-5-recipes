//
//  MainViewController.h
//  Hotspot

#import <UIKit/UIKit.h>
#import "HotspotInfoViewController.h"
#import "Hotspot.h"

@interface MainViewController : UIViewController <HotspotInfoDelegate, UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *tableViewHotspots;

@property (strong, nonatomic) NSMutableArray *hotspots;

@end
