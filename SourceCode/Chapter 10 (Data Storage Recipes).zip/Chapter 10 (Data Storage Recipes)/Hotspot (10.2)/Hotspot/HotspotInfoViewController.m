//
//  HotspotInfoViewController.m
//  Hotspot

#import "HotspotInfoViewController.h"

@implementation HotspotInfoViewController
@synthesize textFieldName;
@synthesize textFieldAddress;
@synthesize textFieldCity;
@synthesize textFieldState;

@synthesize hotspot;
@synthesize delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
-(void)populateWithHotspot
{
    self.textFieldName.text = hotspot.name;
    self.textFieldAddress.text = hotspot.address;
    self.textFieldCity.text = hotspot.city;
    self.textFieldState.text = hotspot.state;
}
- (IBAction)saveButtonPressed:(id)sender 
{
    BOOL isNew;
    if (self.hotspot != nil)
    {
        self.hotspot.name = self.textFieldName.text;
        self.hotspot.address = self.textFieldAddress.text;
        self.hotspot.city = self.textFieldCity.text;
        self.hotspot.state = self.textFieldState.text;
        isNew = NO;
    }
    else
    {
        Hotspot *newHotspot = [[Hotspot alloc] init];
        newHotspot.name = self.textFieldName.text;
        newHotspot.address = self.textFieldAddress.text;
        newHotspot.city = self.textFieldCity.text;
        newHotspot.state = self.textFieldState.text;
        self.hotspot = newHotspot;
        isNew = YES;
    }
    [self.delegate HotspotInfoViewController:self didReturnHotspot:self.hotspot isNew:isNew];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.textFieldName.placeholder = @"Name";
    self.textFieldAddress.placeholder = @"Address";
    self.textFieldCity.placeholder = @"City";
    self.textFieldState.placeholder = @"State";
    
    self.textFieldName.delegate = self;
    self.textFieldAddress.delegate = self;
    self.textFieldCity.delegate = self;
    self.textFieldState.delegate = self;
    
    if (self.hotspot != nil)
    {
        [self populateWithHotspot];
    }
}
- (void)viewDidUnload
{
    [self setTextFieldName:nil];
    [self setTextFieldAddress:nil];
    [self setTextFieldCity:nil];
    [self setTextFieldState:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


@end
