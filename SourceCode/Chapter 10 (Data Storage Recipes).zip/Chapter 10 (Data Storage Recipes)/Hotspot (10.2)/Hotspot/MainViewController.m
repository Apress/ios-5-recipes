//
//  MainViewController.m
//  Hotspot

#import "MainViewController.h"

@implementation MainViewController
@synthesize tableViewHotspots;
@synthesize hotspots;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)saveData
{
    NSString *rootPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *savePath = [rootPath stringByAppendingPathComponent:@"hotspotsData"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableData *saveData = [[NSMutableData alloc] init];
    
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:saveData];
    [archiver encodeObject:self.hotspots forKey:@"DataArray"];
    [archiver finishEncoding];
    
    [fileManager createFileAtPath:savePath contents:saveData attributes:nil];
}
-(void)loadData
{
    NSString *rootPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *savePath = [rootPath stringByAppendingPathComponent:@"hotspotsData"];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if ([fileManager fileExistsAtPath:savePath])
    {
        NSData *data = [fileManager contentsAtPath:savePath];
        NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
        self.hotspots = [unarchiver decodeObjectForKey:@"DataArray"];
    }
}
-(void)HotspotInfoViewController:(HotspotInfoViewController *)hotspotInfoVC didReturnHotspot:(Hotspot *)hotspot isNew:(BOOL)isNew
{
    if (isNew)
    {
        [self.hotspots addObject:hotspot];
    }
    [self.tableViewHotspots reloadData];
    
    //New call to save data
    [self saveData];
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(NSMutableArray *)hotspots
{
    if (!hotspots)
    {
        hotspots = [[NSMutableArray alloc] initWithCapacity:10];
    }
    return hotspots;
}
-(void)newHotspot:(id)sender
{
    HotspotInfoViewController *hotspotVC = [[HotspotInfoViewController alloc] init];
    hotspotVC.delegate = self;
    [self.navigationController pushViewController:hotspotVC animated:YES];
}
-(void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
    [self.tableViewHotspots setEditing:editing animated:animated];
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self loadData];
    
    self.title = @"Hotspots";
    
    self.tableViewHotspots.delegate = self;
    self.tableViewHotspots.dataSource = self;
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(newHotspot:)];
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    self.navigationItem.leftBarButtonItem = addButton;
}

- (void)viewDidUnload
{
    [self setTableViewHotspots:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    self.title = @"Hotspots";
    [super viewWillAppear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
    self.title = @"Cancel";
	[super viewDidDisappear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark - UITableView methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.hotspots count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) 
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    Hotspot *currentHotspot = [self.hotspots objectAtIndex:indexPath.row];
    
    cell.textLabel.text = currentHotspot.name;
    cell.detailTextLabel.text = currentHotspot.address;
    
    return cell;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) 
    {
        [self.hotspots removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        //New call to save data
        [self saveData];
    }
}

- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
    Hotspot *movingHotspot = [self.hotspots objectAtIndex:fromIndexPath.row];
    [self.hotspots removeObject:movingHotspot];
    [self.hotspots insertObject:movingHotspot atIndex:toIndexPath.row];
    [self.tableViewHotspots reloadData];
    //New call to save data
    [self saveData];
}
 
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableViewHotspots deselectRowAtIndexPath:indexPath animated:YES];
    
    HotspotInfoViewController *hotspotVC = [[HotspotInfoViewController alloc] init];
    hotspotVC.delegate = self;
    hotspotVC.hotspot = [self.hotspots objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:hotspotVC animated:YES];
}

@end
