//
//  MainAppDelegate.h
//  Stubborn

#import <UIKit/UIKit.h>

@class MainViewController;

@interface MainAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MainViewController *viewController;

@end
