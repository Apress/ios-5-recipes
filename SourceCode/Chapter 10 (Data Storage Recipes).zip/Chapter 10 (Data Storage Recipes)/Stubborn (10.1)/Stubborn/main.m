//
//  main.m
//  Stubborn

#import <UIKit/UIKit.h>

#import "MainAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MainAppDelegate class]));
    }
}
