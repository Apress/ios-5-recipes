//
//  MainViewController.m
//  Stubborn

#import "MainViewController.h"

@implementation MainViewController
@synthesize firstLabel;
@synthesize secondLabel;
@synthesize animateLabel;
@synthesize firstNameTextField;
@synthesize lastNameTextField;
@synthesize animateSwitch;
@synthesize activityIndicator;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
-(void)updateDefaults
{
    //Acquire Values
    NSString *first = self.firstNameTextField.text;
    NSString *last = self.lastNameTextField.text;
    BOOL animating = self.activityIndicator.isAnimating;
    
    //Acquire Shared Instance
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    //Set Objects/Values to Persist
    [userDefaults setObject:first forKey:@"firstName"];
    [userDefaults setObject:last forKey:@"lastName"];
    [userDefaults setBool:animating forKey:@"animating"];
    
    //Save Changes
    [userDefaults synchronize];
}
-(void)setValuesFromDefaults
{
    //Acquire Shared Instance
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    //Acquire Values
    NSString *first = [userDefaults objectForKey:@"firstName"];
    NSString *last = [userDefaults objectForKey:@"lastName"];
    BOOL animating = [userDefaults boolForKey:@"animating"];
    
    //Display Values Appropriately
    if (first != nil)
    {
        self.firstNameTextField.text = first;
        self.firstLabel.text = first;
    }
    if (last != nil)
    {
        self.lastNameTextField.text = last;
        self.secondLabel.text = last;
    }
    if (animating)
    {
        self.animateLabel.text = @"Animating";
        if (self.activityIndicator.isAnimating == NO)
        {
            [self.activityIndicator startAnimating];
        }
    }
    else 
    {
        self.animateLabel.text = @"Stopped";
        if (self.activityIndicator.isAnimating == YES)
        {
            [self.activityIndicator stopAnimating];
        }
    }
    [self.animateSwitch setOn:animating animated:NO];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    if (textField == self.firstNameTextField)
    {
        self.firstLabel.text = textField.text;
    }
    else if (textField == self.lastNameTextField)
    {
        self.secondLabel.text = textField.text;
    }
    [self updateDefaults];
}
-(void)switchValueChanged:(UISwitch *)sender
{
    if (sender.on)
    {
        [self.activityIndicator startAnimating];
        self.animateLabel.text = @"Animating";
    }
    else
    {
        [self.activityIndicator stopAnimating];
        self.animateLabel.text = @"Stopped";
    }
    [self updateDefaults];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.firstNameTextField.delegate = self;
    self.lastNameTextField.delegate = self;
    
    [self.animateSwitch addTarget:self action:@selector(switchValueChanged:) forControlEvents:UIControlEventValueChanged];
    
    [self setValuesFromDefaults];
}

- (void)viewDidUnload
{
    [self setActivityIndicator:nil];
    [self setAnimateSwitch:nil];
    [self setLastNameTextField:nil];
    [self setFirstNameTextField:nil];
    [self setFirstLabel:nil];
    [self setSecondLabel:nil];
    [self setAnimateLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
