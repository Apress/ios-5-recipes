//
//  MainViewController.m
//  Chapter8Recipe2

#import "MainViewController.h"

@implementation MainViewController
@synthesize eventStore;
@synthesize tableViewEvents;
@synthesize toolBarTop;
@synthesize events, calendars;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)addPressed:(UIButton *)sender
{
    EventAddViewController *addVC = [[EventAddViewController alloc] init];
    addVC.delegate = self;
    [self presentModalViewController:addVC animated:YES];
}

-(EKCalendar *)eventEditViewControllerDefaultCalendarForNewEvents:(EKEventEditViewController *)controller
{
    return [self.eventStore defaultCalendarForNewEvents];
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    EKEventViewController *eventVC = [[EKEventViewController alloc] init];
    eventVC.event = [[self.events objectForKey:[[self.calendars objectAtIndex:indexPath.section] title]] objectAtIndex:indexPath.row];
    eventVC.delegate = self;
    eventVC.allowsEditing = YES;
    UINavigationController *navcon = [[UINavigationController alloc] initWithRootViewController:eventVC];
    [self presentModalViewController:navcon animated:YES];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.calendars count];
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [[self.calendars objectAtIndex:section] title];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *title = [[self.calendars objectAtIndex:section] title];
    NSArray *eventsInThisCalendar = [self.events objectForKey:title];
    return [eventsInThisCalendar count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
	
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    cell.textLabel.backgroundColor = [UIColor clearColor];
    cell.textLabel.font = [UIFont systemFontOfSize:19.0];
    
    cell.textLabel.text = [[[self.events objectForKey:[[self.calendars objectAtIndex:indexPath.section] title]] objectAtIndex:indexPath.row] title];
	
    return cell;
}
-(void)fetchEvents
{
    self.events = nil;
    self.events = [[NSMutableDictionary alloc] initWithCapacity:[self.calendars count]];
    
    for (EKCalendar *cal in self.calendars)
    {
        NSPredicate *calPredicate = [self.eventStore predicateForEventsWithStartDate:[NSDate date] endDate:[NSDate dateWithTimeIntervalSinceNow:(2*24.0*60*60)] calendars:[NSArray arrayWithObject:cal]];
        //Passing nil to calendars means to search all calendars.
        
        NSArray *eventsInThisCalendar = [self.eventStore eventsMatchingPredicate:calPredicate];
        if (eventsInThisCalendar != nil)
        {
            [self.events setObject:eventsInThisCalendar forKey:cal.title];
        }
    }
}
-(void)eventEditViewController:(EKEventEditViewController *)controller didCompleteWithAction:(EKEventEditViewAction)action
{
    if (action == EKEventEditViewActionDeleted)
    {
        [self.eventStore removeEvent:controller.event span:EKSpanThisEvent error:nil];
    }
    else if (action == EKEventEditViewActionSaved)
    {
        [self.eventStore saveEvent:controller.event span:EKSpanThisEvent error:nil];
    }
    [self fetchEvents];
    [self.tableViewEvents reloadData];
    [self dismissModalViewControllerAnimated:YES];
}
-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    EKEventEditViewController *eventEditVC = [[EKEventEditViewController alloc] init];
    eventEditVC.event = [[self.events objectForKey:[[self.calendars objectAtIndex:indexPath.section] title]] objectAtIndex:indexPath.row];
    eventEditVC.eventStore = self.eventStore;
    eventEditVC.editViewDelegate = self;
    [self presentModalViewController:eventEditVC animated:YES];
}
-(void)eventViewController:(EKEventViewController *)controller didCompleteWithAction:(EKEventViewAction)action
{
    EKEvent *event = controller.event;
    if (action == EKEventViewActionDeleted)
    {
        [self.eventStore removeEvent:event span:EKSpanThisEvent error:nil];
    }
    else
    {
        [self.eventStore saveEvent:event span:EKSpanFutureEvents error:nil];
    }
    [self fetchEvents];
    [self.tableViewEvents reloadData];
    [self dismissModalViewControllerAnimated:YES];
}
-(void)EventAddViewController:(EventAddViewController *)controller didSubmitTitle:(NSString *)title
{
    EKEvent *event = [EKEvent eventWithEventStore:self.eventStore];
    event.title = title;
    event.calendar = [self.eventStore defaultCalendarForNewEvents];
    event.startDate = [NSDate dateWithTimeIntervalSinceNow:60*60*24.0];
    event.endDate = [NSDate dateWithTimeInterval:60*60.0 sinceDate:event.startDate];
    [self.eventStore saveEvent:event span:EKSpanThisEvent error:nil];
    [self fetchEvents];
    [self.tableViewEvents reloadData];
    [self dismissModalViewControllerAnimated:YES];
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    ///////////////START OF NEW CODE
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addPressed:)];
    UIBarButtonItem *fixedSpace = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:NULL];
    fixedSpace.width = 265;
    [self.toolBarTop setItems:[NSArray arrayWithObjects:fixedSpace, addButton, nil]];
    ///////////////END OF NEW CODE
    
    self.tableViewEvents.delegate = self;
    self.tableViewEvents.dataSource = self;
    
    self.eventStore = [[EKEventStore alloc] init];
    self.calendars = [self.eventStore calendars];
    
    [self fetchEvents];
}

- (void)viewDidUnload
{
    self.eventStore = nil;
    [self setTableViewEvents:nil];
    [self setToolBarTop:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [self fetchEvents];
    [self.tableViewEvents reloadData];
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
