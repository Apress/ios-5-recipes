//
//  EventAddViewController.h
//  Chapter8Recipe2

#import <UIKit/UIKit.h>

@class EventAddViewController;

@protocol EventAddViewControllerDelegate <NSObject>
-(void)EventAddViewController:(EventAddViewController *)controller didSubmitTitle:(NSString *)title;
@end

@interface EventAddViewController : UIViewController <UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *textFieldTitle;
@property (strong, nonatomic) IBOutlet UIButton *doneButton;
@property (strong, nonatomic) id <EventAddViewControllerDelegate> delegate;
-(IBAction)donePressed:(id)sender;

@end
