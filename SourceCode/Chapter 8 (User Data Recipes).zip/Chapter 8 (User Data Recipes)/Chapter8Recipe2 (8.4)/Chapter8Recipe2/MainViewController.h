//
//  MainViewController.h
//  Chapter8Recipe2

#import <UIKit/UIKit.h>
#import <EventKit/EventKit.h>
#import <EventKitUI/EventKitUI.h>

@interface MainViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, EKEventViewDelegate, EKEventEditViewDelegate>
{
    UITableView *tableViewEvents;
}


@property (nonatomic, strong) EKEventStore *eventStore;
@property (strong, nonatomic) IBOutlet UITableView *tableViewEvents;

@property (nonatomic, strong) NSMutableDictionary *events;
@property (nonatomic, strong) NSArray *calendars;
@end
