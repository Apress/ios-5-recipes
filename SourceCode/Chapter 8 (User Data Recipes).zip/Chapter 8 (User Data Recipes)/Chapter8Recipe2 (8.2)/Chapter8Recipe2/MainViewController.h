//
//  MainViewController.h
//  Chapter8Recipe2

#import <UIKit/UIKit.h>
#import <EventKit/EventKit.h>

@interface MainViewController : UIViewController
@property (strong, nonatomic) EKEventStore *eventStore;
@end
