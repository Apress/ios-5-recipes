//
//  MainViewController.m
//  Chapter8Recipe8

#import "MainViewController.h"

@implementation MainViewController
@synthesize textFieldFirst;
@synthesize textFieldLast;
@synthesize textFieldPhone;
@synthesize textFieldStreet;
@synthesize textFieldCity;
@synthesize textFieldState;
@synthesize textFieldZip;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)newPersonViewController:(ABNewPersonViewController *)newPersonView didCompleteWithNewPerson:(ABRecordRef)person
{
    if (person == NULL)
    {
        NSLog(@"User Cancelled Creation");
    }
    else
        NSLog(@"Successfully Created New Person");
    [self dismissModalViewControllerAnimated:YES];
}
-(void)newContactPressed:(id)sender
{
    ABNewPersonViewController *view = [[ABNewPersonViewController alloc] init];
    view.newPersonViewDelegate = self;
    
    ABMutableMultiValueRef multi =
    ABMultiValueCreateMutable(kABMultiStringPropertyType);
    CFErrorRef anError = NULL;
    ABMultiValueIdentifier multivalueIdentifier;
    bool didAdd, didSet;
    
    didAdd = ABMultiValueAddValueAndLabel(multi, (__bridge CFStringRef)self.textFieldPhone.text,
                                          kABPersonPhoneMobileLabel, &multivalueIdentifier);
    if (!didAdd)
    {
        NSLog(@"Error Adding Phone Number");
    }
    
    ABRecordRef aRecord = ABPersonCreate();
    
    ABRecordSetValue(aRecord, kABPersonFirstNameProperty, (__bridge CFStringRef)self.textFieldFirst.text, nil);
    ABRecordSetValue(aRecord, kABPersonLastNameProperty, (__bridge CFStringRef)self.textFieldLast.text, nil);
    
    didSet = ABRecordSetValue(aRecord, kABPersonPhoneProperty, multi, &anError);
    if (!didSet) 
    {
        NSLog(@"Error Setting Phone Value");
    }
    CFRelease(multi);
    
    ABMutableMultiValueRef address =
    ABMultiValueCreateMutable(kABDictionaryPropertyType);
    
    // Set up keys and values for the dictionary.
    CFStringRef keys[5];
    CFStringRef values[5];
    keys[0] = kABPersonAddressStreetKey;
    keys[1] = kABPersonAddressCityKey;
    keys[2] = kABPersonAddressStateKey;
    keys[3] = kABPersonAddressZIPKey;
    keys[4] = kABPersonAddressCountryKey;
    values[0] = (__bridge CFStringRef)self.textFieldStreet.text;
    values[1] = (__bridge CFStringRef)self.textFieldCity.text;
    values[2] = (__bridge CFStringRef)self.textFieldState.text;
    values[3] = (__bridge CFStringRef)self.textFieldZip.text;
    values[4] = CFSTR("USA");
    
    CFDictionaryRef aDict = CFDictionaryCreate(kCFAllocatorDefault,(void *)keys,
                                               (void *)values,5,
                                               &kCFCopyStringDictionaryKeyCallBacks,
                                               &kCFTypeDictionaryValueCallBacks);
    
    ABMultiValueIdentifier dictionaryIdentifier;
    bool didAddAddress;
    didAddAddress = ABMultiValueAddValueAndLabel(address, aDict, kABHomeLabel, &dictionaryIdentifier);
    if (!didAddAddress) 
    {
        NSLog(@"Error Adding Address");
    }
    
    CFRelease(aDict);
    
    ABRecordSetValue(aRecord, kABPersonAddressProperty, address, nil);
    
    view.displayedPerson = aRecord;
    
    
    UINavigationController *newNavigationController = [[UINavigationController alloc] initWithRootViewController:view];
    [self presentModalViewController:newNavigationController animated:YES];
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setTextFieldFirst:nil];
    [self setTextFieldLast:nil];
    [self setTextFieldPhone:nil];
    [self setTextFieldStreet:nil];
    [self setTextFieldCity:nil];
    [self setTextFieldState:nil];
    [self setTextFieldZip:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
@end
