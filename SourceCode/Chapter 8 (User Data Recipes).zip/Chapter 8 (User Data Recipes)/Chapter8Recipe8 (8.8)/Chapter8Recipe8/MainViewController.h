//
//  MainViewController.h
//  Chapter8Recipe8

#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>

@interface MainViewController : UIViewController <ABNewPersonViewControllerDelegate>

- (IBAction)newContactPressed:(id)sender;
@property (strong, nonatomic) IBOutlet UITextField *textFieldFirst;
@property (strong, nonatomic) IBOutlet UITextField *textFieldLast;
@property (strong, nonatomic) IBOutlet UITextField *textFieldPhone;
@property (strong, nonatomic) IBOutlet UITextField *textFieldStreet;
@property (strong, nonatomic) IBOutlet UITextField *textFieldCity;
@property (strong, nonatomic) IBOutlet UITextField *textFieldState;
@property (strong, nonatomic) IBOutlet UITextField *textFieldZip;

@end
