//
//  MainViewController.m
//  Chapter8Recipe2

#import "MainViewController.h"

@implementation MainViewController
@synthesize eventStore;
@synthesize tableViewEvents;
@synthesize events, calendars;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.calendars count];
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    return [[self.calendars objectAtIndex:section] title];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSString *title = [[self.calendars objectAtIndex:section] title];
    NSArray *eventsInThisCalendar = [self.events objectForKey:title];
    return [eventsInThisCalendar count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
	
    cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
    cell.textLabel.backgroundColor = [UIColor clearColor];
    cell.textLabel.font = [UIFont systemFontOfSize:19.0];
    
    cell.textLabel.text = [[[self.events objectForKey:[[self.calendars objectAtIndex:indexPath.section] title]] objectAtIndex:indexPath.row] title];
	
    return cell;
}
-(void)fetchEvents
{
    self.events = nil;
    self.events = [[NSMutableDictionary alloc] initWithCapacity:[self.calendars count]];
    
    for (EKCalendar *cal in self.calendars)
    {
        NSPredicate *calPredicate = [self.eventStore predicateForEventsWithStartDate:[NSDate date] endDate:[NSDate dateWithTimeIntervalSinceNow:(2*24.0*60*60)] calendars:[NSArray arrayWithObject:cal]];
        //Passing nil to calendars means to search all calendars.
        
        NSArray *eventsInThisCalendar = [self.eventStore eventsMatchingPredicate:calPredicate];
        if (eventsInThisCalendar != nil)
        {
            [self.events setObject:eventsInThisCalendar forKey:cal.title];
        }
    }
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableViewEvents.delegate = self;
    self.tableViewEvents.dataSource = self;
    
    self.eventStore = [[EKEventStore alloc] init];
    self.calendars = [self.eventStore calendars];
    
    [self fetchEvents];
}

- (void)viewDidUnload
{
    self.eventStore = nil;
    [self setTableViewEvents:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
