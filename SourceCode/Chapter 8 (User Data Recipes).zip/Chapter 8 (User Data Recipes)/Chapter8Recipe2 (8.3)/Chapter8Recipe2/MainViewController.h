//
//  MainViewController.h
//  Chapter8Recipe2

#import <UIKit/UIKit.h>
#import <EventKit/EventKit.h>

@interface MainViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>{
    UITableView *tableViewEvents;
}


@property (nonatomic, strong) EKEventStore *eventStore;
@property (strong, nonatomic) IBOutlet UITableView *tableViewEvents;

@property (nonatomic, strong) NSMutableDictionary *events;
@property (nonatomic, strong) NSArray *calendars;
@end
