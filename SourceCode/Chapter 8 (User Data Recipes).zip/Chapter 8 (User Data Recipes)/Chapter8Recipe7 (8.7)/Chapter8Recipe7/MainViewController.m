//
//  MainViewController.m
//  Chapter8Recipe7

#import "MainViewController.h"

@implementation MainViewController
@synthesize firstLabel;
@synthesize lastLabel;
@synthesize phoneLabel;
@synthesize cityLabel;
@synthesize stateLabel;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.firstLabel.text = @"...";
    self.lastLabel.text = @"...";
    self.phoneLabel.text = @"...";
    self.cityLabel.text = @"...";
    self.stateLabel.text = @"...";
}

- (void)viewDidUnload
{
    [self setFirstLabel:nil];
    [self setLastLabel:nil];
    [self setPhoneLabel:nil];
    [self setCityLabel:nil];
    [self setStateLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}


-(BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker shouldContinueAfterSelectingPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier
{
    [self dismissModalViewControllerAnimated:YES];
    return NO;
}
-(BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker shouldContinueAfterSelectingPerson:(ABRecordRef)person
{
    self.firstLabel.text = (__bridge_transfer NSString *)ABRecordCopyValue(person, kABPersonFirstNameProperty);
    self.lastLabel.text = (__bridge_transfer NSString *)ABRecordCopyValue(person, kABPersonLastNameProperty);
    
    ABMultiValueRef multi = ABRecordCopyValue(person, kABPersonPhoneProperty);
    CFStringRef phoneNumber = ABMultiValueCopyValueAtIndex(multi, 0);
    self.phoneLabel.text = (__bridge_transfer NSString *)phoneNumber;
    CFRelease(phoneNumber);
    
    ABMultiValueRef address = ABRecordCopyValue(person, kABPersonAddressProperty);
    if (ABMultiValueGetCount(address) > 0) 
    {
        CFDictionaryRef dictionary = ABMultiValueCopyValueAtIndex
        (address, 0);
        CFStringRef cityKey = kABPersonAddressCityKey;
        CFStringRef stateKey = kABPersonAddressStateKey;
        self.cityLabel.text = (__bridge_transfer NSString *)CFDictionaryGetValue(dictionary, (void *)cityKey);
        self.stateLabel.text = (__bridge_transfer NSString *)CFDictionaryGetValue(dictionary, (void *)stateKey);
        
        CFRelease(dictionary);
        CFRelease(cityKey);
        CFRelease(stateKey);
    }
    else
    {
        self.cityLabel.text = @"...";
        self.stateLabel.text = @"...";
    }
    
    [self dismissModalViewControllerAnimated:YES];
    return NO;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
-(void)peoplePickerNavigationControllerDidCancel:(ABPeoplePickerNavigationController *)peoplePicker
{
    [self dismissModalViewControllerAnimated:YES];
}
-(void)findPressed:(id)sender
{
    ABPeoplePickerNavigationController *picker =[[ABPeoplePickerNavigationController alloc] init];
    picker.peoplePickerDelegate = self;
    [self presentModalViewController:picker animated:YES];
}
@end
