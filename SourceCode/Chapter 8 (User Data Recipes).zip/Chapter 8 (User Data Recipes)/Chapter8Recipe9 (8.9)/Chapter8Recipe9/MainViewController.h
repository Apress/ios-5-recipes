//
//  MainViewController.h
//  Chapter8Recipe9

#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>

@interface MainViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, ABPersonViewControllerDelegate>

@property (strong, nonatomic) IBOutlet UITableView *tableViewContacts;
@property (strong, nonatomic) NSArray *contacts;
@end
