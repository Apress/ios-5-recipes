//
//  MainViewController.m
//  Chapter8Recipe9

#import "MainViewController.h"

@implementation MainViewController
@synthesize tableViewContacts;
@synthesize contacts;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)updateContacts
{
    ABAddressBookRef addressBook = ABAddressBookCreate();
    CFArrayRef people = ABAddressBookCopyArrayOfAllPeople(addressBook);
    self.contacts = (__bridge NSArray *)people;
    CFRelease(people);
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableViewContacts.delegate = self;
    self.tableViewContacts.dataSource = self;
    self.title = @"Contacts Table";
    [self updateContacts];
}

- (void)viewDidUnload
{
    self.tableViewContacts.delegate = nil;
    self.tableViewContacts.dataSource = nil;
    self.contacts = nil;
    [self setTableViewContacts:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [self updateContacts];
    [self.tableViewContacts reloadData];
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
    }
	
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.backgroundColor = [UIColor clearColor];
    cell.textLabel.font = [UIFont systemFontOfSize:19.0];
    
    ABRecordRef current = (__bridge ABRecordRef)[self.contacts objectAtIndex:indexPath.row];
    
    NSString *firstName = (__bridge_transfer NSString *)ABRecordCopyValue(current, kABPersonFirstNameProperty);
    NSString *lastName = (__bridge_transfer NSString *)ABRecordCopyValue(current, kABPersonLastNameProperty);
    
    cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
	
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ABRecordRef chosen = (__bridge ABRecordRef)[self.contacts objectAtIndex:indexPath.row];
    
    ABPersonViewController *view = [[ABPersonViewController alloc] init];
    view.personViewDelegate = self;
    view.displayedPerson = chosen;
    view.allowsEditing = NO;
    
    [self.navigationController pushViewController:view animated:YES];
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}
-(BOOL)personViewController:(ABPersonViewController *)personViewController shouldPerformDefaultActionForPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier
{
    return YES;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[NSNumber numberWithInt:[self.contacts count]] intValue];
}

@end
