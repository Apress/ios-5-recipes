//
//  MainViewController.m
//  CalendarConvert

#import "MainViewController.h"

@implementation MainViewController
@synthesize textFieldGMonth;
@synthesize textFieldGDay;
@synthesize textFieldGYear;
@synthesize textFieldHMonth;
@synthesize textFieldHDay;
@synthesize textFieldHYear;

@synthesize gregorianCalendar, hebrewCalendar;

-(NSCalendar *)gregorianCalendar
{
    if (!gregorianCalendar)
    {
        gregorianCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    }
    return gregorianCalendar;
}
-(NSCalendar *)hebrewCalendar
{
    if (!hebrewCalendar)
    {
        hebrewCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSHebrewCalendar];
    }
    return hebrewCalendar;
}
-(void)convertToGregorian:(id)sender
{
    NSDateComponents *hComponents = [[NSDateComponents alloc] init];
    [hComponents setDay:[self.textFieldHDay.text integerValue]];
    [hComponents setMonth:[self.textFieldHMonth.text integerValue]];
    [hComponents setYear:[self.textFieldHYear.text integerValue]];
    
    NSDate *hebrewDate = [self.hebrewCalendar dateFromComponents:hComponents];
    
    NSUInteger unitFlags = NSDayCalendarUnit | NSMonthCalendarUnit |
    NSYearCalendarUnit;
    
    NSDateComponents *hebrewDateComponents = [self.gregorianCalendar components:unitFlags fromDate:hebrewDate];
    
    self.textFieldGDay.text = [[NSNumber numberWithInteger:hebrewDateComponents.day] stringValue];
    self.textFieldGMonth.text = [[NSNumber numberWithInteger:hebrewDateComponents.month] stringValue];
    self.textFieldGYear.text = [[NSNumber numberWithInteger:hebrewDateComponents.year] stringValue];
}
-(void)convertToHebrew:(id)sender
{
    NSDateComponents *gComponents = [[NSDateComponents alloc] init];
    [gComponents setDay:[self.textFieldGDay.text integerValue]];
    [gComponents setMonth:[self.textFieldGMonth.text integerValue]];
    [gComponents setYear:[self.textFieldGYear.text integerValue]];
    
    NSDate *gregorianDate = [self.gregorianCalendar dateFromComponents:gComponents];
    
    NSUInteger unitFlags = NSDayCalendarUnit | NSMonthCalendarUnit |
    NSYearCalendarUnit;
    
    NSDateComponents *hebrewDateComponents = [self.hebrewCalendar components:unitFlags fromDate:gregorianDate];
    
    self.textFieldHDay.text = [[NSNumber numberWithInteger:hebrewDateComponents.day] stringValue];
    self.textFieldHMonth.text = [[NSNumber numberWithInteger:hebrewDateComponents.month] stringValue];
    self.textFieldHYear.text = [[NSNumber numberWithInteger:hebrewDateComponents.year] stringValue];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    for (UITextField *field in self.view.subviews)
    {
        if ([field respondsToSelector:@selector(setDelegate:)])
        {
            field.delegate = self;
        } 
    }
	
}
- (void)viewDidUnload
{
    self.gregorianCalendar = nil;
    self.hebrewCalendar = nil;
    [self setTextFieldGMonth:nil];
    [self setTextFieldGDay:nil];
    [self setTextFieldGYear:nil];
    [self setTextFieldHMonth:nil];
    [self setTextFieldHDay:nil];
    [self setTextFieldHYear:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
