//
//  MainViewController.h
//  CalendarConvert

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController <UITextFieldDelegate>{
    UITextField *textFieldGMonth;
    UITextField *textFieldGDay;
    UITextField *textFieldGYear;
    UITextField *textFieldHMonth;
    UITextField *textFieldHDay;
    UITextField *textFieldHYear;
}

@property (strong, nonatomic) IBOutlet UITextField *textFieldGMonth;
@property (strong, nonatomic) IBOutlet UITextField *textFieldGDay;
@property (strong, nonatomic) IBOutlet UITextField *textFieldGYear;
@property (strong, nonatomic) IBOutlet UITextField *textFieldHMonth;
@property (strong, nonatomic) IBOutlet UITextField *textFieldHDay;
@property (strong, nonatomic) IBOutlet UITextField *textFieldHYear;

-(IBAction)convertToHebrew:(id)sender;
-(IBAction)convertToGregorian:(id)sender;

@property (nonatomic, strong) NSCalendar *gregorianCalendar;
@property (nonatomic, strong) NSCalendar *hebrewCalendar;
@end
