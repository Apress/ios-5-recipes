//
//  MainViewController.h
//  SendItOut

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <MessageUI/MessageUI.h>

@interface MainViewController : UIViewController <UITextViewDelegate, MFMessageComposeViewControllerDelegate, UINavigationControllerDelegate>

@property (weak, nonatomic) IBOutlet UITextView *textViewInput;
@property (weak, nonatomic) IBOutlet UIButton *textButton;
-(IBAction)textPressed:(id)sender;

@end
