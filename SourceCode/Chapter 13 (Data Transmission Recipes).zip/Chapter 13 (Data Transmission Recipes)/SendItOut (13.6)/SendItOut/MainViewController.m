//
//  MainViewController.m
//  SendItOut

#import "MainViewController.h"

@implementation MainViewController
@synthesize mailButton;
@synthesize imageViewContent;
@synthesize textViewInput;
@synthesize textButton;
@synthesize selectedImage;
@synthesize pop;
@synthesize getImageButton;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range 
 replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) 
    {
        [textView resignFirstResponder];
        return FALSE;
    }
    return TRUE;
}
-(void)mailComposeController:(MFMailComposeViewController *)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError *)error
{
    if (result == MFMailComposeResultSent)
        NSLog(@"Mail Successfully Sent");
    else if (result == MFMailComposeResultCancelled)
        NSLog(@"Mail Cancelled");
    else if (result == MFMailComposeResultFailed)
        NSLog(@"Error, Mail Send Failed");
    else if (result == MFMailComposeResultSaved)
        NSLog(@"Mail Saved");
    [self dismissModalViewControllerAnimated:YES];
}
-(void)mailPressed:(id)sender
{
    if ([MFMailComposeViewController canSendMail])
    {
        MFMailComposeViewController *mailVC = [[MFMailComposeViewController alloc] init];
        [mailVC setSubject:@"SendItOut"];
        [mailVC setToRecipients:[NSArray arrayWithObject:@"test@senditout.test"]];
        [mailVC setMessageBody:self.textViewInput.text isHTML:NO];
        mailVC.mailComposeDelegate = self;
        
        /////NEW IMAGE CODE
        if (self.selectedImage != nil)
        {
            NSData *imageData = UIImageJPEGRepresentation(self.selectedImage, 1.0);
            [mailVC addAttachmentData:imageData mimeType:@"image/jpeg" fileName:@"SelectedImage"];
        }
        /////END OF NEW CODE
        
        [self presentModalViewController:mailVC animated:YES];
    }
    else
    {
        NSLog(@"Error: Mail Unavailable");
    }
}
-(void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result
{
    if (result == MessageComposeResultSent)
    {
        self.textViewInput.text = @"Message sent.";
        self.selectedImage = nil;
        self.imageViewContent.image = nil;
    }
    else if (result == MessageComposeResultFailed)
    {
        NSLog(@"Message Failed to Send!");
    }
    [self dismissModalViewControllerAnimated:YES];
}
-(void)textPressed:(id)sender
{
    if ([MFMessageComposeViewController canSendText])
    {
        MFMessageComposeViewController *messageVC = [[MFMessageComposeViewController alloc] init];
        messageVC.messageComposeDelegate = self;
        messageVC.recipients = [NSArray arrayWithObject:@"3015555309"];
        messageVC.body = self.textViewInput.text;
        [self presentModalViewController:messageVC animated:YES];
    }
    else
    {
        NSLog(@"Error, Text Messaging Unavailable");
    }
}

-(void)availabilityChange:(id)sender
{
    if ([MFMessageComposeViewController canSendText])
    {
        NSLog(@"Text Messaging Available");
    }
    else
    {
        NSLog(@"Text Messaging Unavailable");
    }
}
#pragma mark - View lifecycle
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self.pop dismissPopoverAnimated:YES];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = [info valueForKey:@"UIImagePickerControllerOriginalImage"];
    self.selectedImage = image;
    self.imageViewContent.image = image;
    self.imageViewContent.contentMode = UIViewContentModeScaleAspectFill;   
    
    [self.pop dismissPopoverAnimated:YES];
}
-(void)getImagePressed:(UIButton *)sender
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
    {
        picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        picker.delegate = self;
        
        self.pop = [[UIPopoverController alloc] initWithContentViewController:picker];
        pop.delegate = self;
        [pop presentPopoverFromRect:sender.frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }
}
-(void)printPressed:(id)sender
{
    if ([UIPrintInteractionController isPrintingAvailable] && (self.selectedImage != nil))
    {
        UIPrintInteractionController *pic = [UIPrintInteractionController sharedPrintController];
    
        UIPrintInfo *printInfo = [UIPrintInfo printInfo];
        printInfo.outputType = UIPrintInfoOutputPhoto;
        printInfo.jobName = self.title;
        printInfo.duplex = UIPrintInfoDuplexLongEdge;
        
        UIImage *image = self.selectedImage;
        pic.printingItem = image;
    
        if (!pic.printingItem && image.size.width > image.size.height)
            printInfo.orientation = UIPrintInfoOrientationLandscape;
    
        pic.printInfo = printInfo;
        pic.showsPageRange = YES;
    
        [pic presentFromBarButtonItem:sender animated:YES completionHandler:^(UIPrintInteractionController *printInteractionController, BOOL completed, NSError *error)
         {
             if (!completed && (error != nil))
             {
                 NSLog(@"Error due to Domain: %@, Code: %@", error.domain, error.code);
             }
             else
             {
                 NSLog(@"Printing Cancelled");
             }
         }];
    }
}
-(void)printTextPressed:(id)sender
{
    if ([UIPrintInteractionController isPrintingAvailable])
    {
        UIPrintInteractionController *pic = [UIPrintInteractionController sharedPrintController];
        
        UIPrintInfo *printInfo = [UIPrintInfo printInfo];
        printInfo.outputType = UIPrintInfoOutputGeneral; 
        printInfo.jobName = self.title;
        printInfo.duplex = UIPrintInfoDuplexLongEdge;
        pic.printInfo = printInfo;
        
        UISimpleTextPrintFormatter *simpleTextPF = [[UISimpleTextPrintFormatter alloc] initWithText:self.textViewInput.text];
        simpleTextPF.startPage = 0;
        simpleTextPF.contentInsets = UIEdgeInsetsMake(72.0, 72.0, 72.0, 72.0);
        simpleTextPF.maximumContentWidth = 6*72.0;
        
        pic.printFormatter = simpleTextPF;
        
        pic.showsPageRange = YES;
        
        [pic presentFromBarButtonItem:sender animated:YES completionHandler:^(UIPrintInteractionController *printInteractionController, BOOL completed, NSError *error)
         {
             if (!completed && (error != nil))
             {
                 NSLog(@"Error due to Domain: %@, Code: %@", error.domain, error.code);
             }
             else
             {
                 NSLog(@"Printing Cancelled");
             }
         }];
    }
}
-(void)printViewPressed:(id)sender
{
    if ([UIPrintInteractionController isPrintingAvailable])
    {
        UIPrintInteractionController *pic = [UIPrintInteractionController sharedPrintController];
        
        UIPrintInfo *printInfo = [UIPrintInfo printInfo];
        printInfo.outputType = UIPrintInfoOutputGeneral;
        printInfo.jobName = self.title;
        printInfo.duplex = UIPrintInfoDuplexLongEdge;
        printInfo.orientation = UIPrintInfoOrientationLandscape;
        pic.printInfo = printInfo;
        
        UIViewPrintFormatter *viewPF = [self.textViewInput viewPrintFormatter];
        
        pic.printFormatter = viewPF;
        pic.showsPageRange = YES;
        
        [pic presentFromBarButtonItem:sender animated:YES completionHandler:^(UIPrintInteractionController *printInteractionController, BOOL completed, NSError *error)
         {
             if (!completed && (error != nil))
             {
                 NSLog(@"Error due to Domain: %@, Code: %@", error.domain, error.code);
             }
             else
             {
                 NSLog(@"Printing Cancelled");
             }
         }];
    }
}
-(void)printCustomPressed:(id)sender
{
    if ([UIPrintInteractionController isPrintingAvailable])
    {
        UIPrintInteractionController *pic = [UIPrintInteractionController sharedPrintController];
        
        UIPrintInfo *printInfo = [UIPrintInfo printInfo];
        printInfo.outputType = UIPrintInfoOutputGeneral;
        printInfo.jobName = self.title;
        printInfo.duplex = UIPrintInfoDuplexLongEdge;
        printInfo.orientation = UIPrintInfoOrientationPortrait;
        pic.printInfo = printInfo;
        
        UISimpleTextPrintFormatter *simplePF = [[UISimpleTextPrintFormatter alloc] initWithText:[self.textViewInput.text stringByAppendingString:@"THIS TEXT IS MY FIRST PAGE"]];
        UIViewPrintFormatter *viewPF = [self.textViewInput viewPrintFormatter];
        
        SendItOutPageRenderer *sendPR = [[SendItOutPageRenderer alloc] init];
        sendPR.title = @"My Print Job Title";
        sendPR.author = @"Document Author";
        sendPR.headerHeight = 72.0/2;
        sendPR.footerHeight = 72.0/2;
        [sendPR addPrintFormatter:simplePF startingAtPageAtIndex:0];
        [sendPR addPrintFormatter:viewPF startingAtPageAtIndex:1];
        
        pic.printPageRenderer = sendPR;
        
        pic.showsPageRange = YES;
        
        [pic presentFromBarButtonItem:sender animated:YES completionHandler:^(UIPrintInteractionController *printInteractionController, BOOL completed, NSError *error)
         {
             if (!completed && (error != nil))
             {
                 NSLog(@"Error due to Domain: %@, Code: %@", error.domain, error.code);
             }
             else
             {
                 NSLog(@"Printing Cancelled");
             }
         }];
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(availabilityChange:) name:@"MFMessageComposeViewControllerTextMessageAvailabilityDidChangeNotification"object:nil];
    
    self.textViewInput.layer.cornerRadius = 15.0;
    self.textViewInput.delegate = self;
    
    self.title = @"Send It Out!";
    
    if ([UIPrintInteractionController isPrintingAvailable])
    {
        UIBarButtonItem *printButton = [[UIBarButtonItem alloc] initWithTitle:@"Print Image" style:UIBarButtonItemStyleBordered target:self action:@selector(printPressed:)];
        
        UIBarButtonItem *printTextButton = [[UIBarButtonItem alloc] initWithTitle:@"Print Text" style:UIBarButtonItemStyleBordered target:self action:@selector(printTextPressed:)];
        
        UIBarButtonItem *printViewButton = [[UIBarButtonItem alloc] initWithTitle:@"Print View" style:UIBarButtonItemStyleBordered target:self action:@selector(printViewPressed:)];
        
        UIBarButtonItem *printCustomButton = [[UIBarButtonItem alloc] initWithTitle:@"Print Custom"style:UIBarButtonItemStyleBordered target:self action:@selector(printCustomPressed:)];
        
        self.navigationItem.rightBarButtonItems = [NSArray arrayWithObjects:printButton, printTextButton, printViewButton, printCustomButton, nil];
    }
}

- (void)viewDidUnload
{
    [self setPop:nil];
    [self setSelectedImage:nil];
    [self setTextViewInput:nil];
    [self setTextButton:nil];
    [self setMailButton:nil];
    [self setImageViewContent:nil];
    [self setGetImageButton:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

@end
