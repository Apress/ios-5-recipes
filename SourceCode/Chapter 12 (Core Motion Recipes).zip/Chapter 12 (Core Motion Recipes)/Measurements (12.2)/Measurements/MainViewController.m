//
//  MainViewController.m
//  CoreMotionTest

#import "MainViewController.h"

@implementation MainViewController
@synthesize motionManager;
@synthesize xAccLabel;
@synthesize yAccLabel;
@synthesize zAccLabel;
@synthesize xGyroLabel;
@synthesize yGyroLabel;
@synthesize zGyroLabel;
@synthesize xMagLabel;
@synthesize yMagLabel;
@synthesize zMagLabel;
@synthesize rollLabel;
@synthesize pitchLabel;
@synthesize yawLabel;
@synthesize statusLabel;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(CMMotionManager *)motionManager
{
    if (motionManager == nil)
    {
        motionManager = [[CMMotionManager alloc] init];
    }
    return motionManager;
}
#pragma mark - View lifecycle
-(void)shakeDetected:(NSNotification *)paramNotification
{
    if ([self.statusLabel.text isEqualToString:@"Updating"])
    {
        self.statusLabel.text = @"Stopped";
        [self toggleUpdates];
    }
    else
    {
        self.statusLabel.text = @"Updating";
        [self toggleUpdates];
    }
}
-(void)toggleUpdates
{
    if ([self.motionManager isDeviceMotionAvailable] && ![self.motionManager isDeviceMotionActive])
    {
        [self.motionManager setDeviceMotionUpdateInterval:1.0/2.0];
        [self.motionManager startDeviceMotionUpdatesUsingReferenceFrame:CMAttitudeReferenceFrameXMagneticNorthZVertical toQueue:[NSOperationQueue mainQueue] withHandler:^(CMDeviceMotion *motion, NSError *error)
         {
             self.xAccLabel.text = [NSString stringWithFormat:@"%f", motion.gravity.x];
             self.yAccLabel.text = [NSString stringWithFormat:@"%f", motion.gravity.y];
             self.zAccLabel.text = [NSString stringWithFormat:@"%f", motion.gravity.z];
             
             self.xGyroLabel.text = [NSString stringWithFormat:@"%f", motion.rotationRate.x];
             self.yGyroLabel.text = [NSString stringWithFormat:@"%f", motion.rotationRate.y];
             self.zGyroLabel.text = [NSString stringWithFormat:@"%f", motion.rotationRate.z];
             
             self.xMagLabel.text = [NSString stringWithFormat:@"%f", motion.magneticField.field.x];
             self.yMagLabel.text = [NSString stringWithFormat:@"%f", motion.magneticField.field.y];
             self.zMagLabel.text = [NSString stringWithFormat:@"%f", motion.magneticField.field.z];
             
             self.rollLabel.text = [NSString stringWithFormat:@"%f", motion.attitude.roll];
             self.pitchLabel.text = [NSString stringWithFormat:@"%f", motion.attitude.pitch];
             self.yawLabel.text = [NSString stringWithFormat:@"%f", motion.attitude.yaw];
         }];
    }
    else if ([self.motionManager isDeviceMotionActive])
    {
        [self.motionManager stopDeviceMotionUpdates];
        
        self.xAccLabel.text = @"...";
        self.yAccLabel.text = @"...";
        self.zAccLabel.text = @"...";
        self.xGyroLabel.text = @"...";
        self.yGyroLabel.text = @"...";
        self.zGyroLabel.text = @"...";
        self.xMagLabel.text = @"...";
        self.yMagLabel.text = @"...";
        self.zMagLabel.text = @"...";
        
        //////NEW ATTITUDE CODE
        self.rollLabel.text = @"...";
        self.pitchLabel.text = @"...";
        self.yawLabel.text = @"...";
        //////END OF NEW CODE
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(shakeDetected:) name:@"NOTIFICATION_SHAKE" object:nil];
    
    
}
- (void)viewDidUnload
{
    if ([self.motionManager isDeviceMotionAvailable] && [self.motionManager isDeviceMotionActive])
    {
        [self.motionManager stopDeviceMotionUpdates];
    }
    
    self.motionManager = nil;
    [self setXAccLabel:nil];
    [self setYAccLabel:nil];
    [self setZAccLabel:nil];
    [self setXGyroLabel:nil];
    [self setYGyroLabel:nil];
    [self setZGyroLabel:nil];
    [self setStatusLabel:nil];
    [self setXMagLabel:nil];
    [self setYMagLabel:nil];
    [self setZMagLabel:nil];
    [self setRollLabel:nil];
    [self setPitchLabel:nil];
    [self setYawLabel:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
