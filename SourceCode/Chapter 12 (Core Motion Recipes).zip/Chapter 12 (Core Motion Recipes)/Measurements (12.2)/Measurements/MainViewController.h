//
//  MainViewController.h
//  CoreMotionTest

#import <UIKit/UIKit.h>
#import <CoreMotion/CoreMotion.h>

@interface MainViewController : UIViewController {
    UILabel *xLabel;
    UILabel *yLabel;
    UILabel *zLabel;
    UILabel *xGyroLabel;
    UILabel *yGyroLabel;
    UILabel *zGyroLabel;
    UILabel *xMagLabel;
    UILabel *yMagLabel;
    UILabel *zMagLabel;
    UILabel *rollLabel;
    UILabel *pitchLabel;
    UILabel *yawLabel;
    UILabel *statusLabel;
}

@property (nonatomic, strong) CMMotionManager *motionManager;
@property (strong, nonatomic) IBOutlet UILabel *xAccLabel;
@property (strong, nonatomic) IBOutlet UILabel *yAccLabel;
@property (strong, nonatomic) IBOutlet UILabel *zAccLabel;

@property (strong, nonatomic) IBOutlet UILabel *xGyroLabel;
@property (strong, nonatomic) IBOutlet UILabel *yGyroLabel;
@property (strong, nonatomic) IBOutlet UILabel *zGyroLabel;

@property (strong, nonatomic) IBOutlet UILabel *xMagLabel;
@property (strong, nonatomic) IBOutlet UILabel *yMagLabel;
@property (strong, nonatomic) IBOutlet UILabel *zMagLabel;

@property (strong, nonatomic) IBOutlet UILabel *rollLabel;
@property (strong, nonatomic) IBOutlet UILabel *pitchLabel;
@property (strong, nonatomic) IBOutlet UILabel *yawLabel;

@property (strong, nonatomic) IBOutlet UILabel *statusLabel;

-(void)toggleUpdates;

@end
