//
//  MainViewController.m
//  CoreMotionTest

#import "MainViewController.h"

@implementation MainViewController
@synthesize motionManager;
@synthesize xAccLabel;
@synthesize yAccLabel;
@synthesize zAccLabel;
@synthesize xGyroLabel;
@synthesize yGyroLabel;
@synthesize zGyroLabel;
@synthesize xMagLabel;
@synthesize yMagLabel;
@synthesize zMagLabel;
@synthesize rollLabel;
@synthesize pitchLabel;
@synthesize yawLabel;
@synthesize statusLabel;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(CMMotionManager *)motionManager
{
    if (motionManager == nil)
    {
        motionManager = [[CMMotionManager alloc] init];
    }
    return motionManager;
}
#pragma mark - View lifecycle
-(void)shakeDetected:(NSNotification *)paramNotification
{
    if ([self.statusLabel.text isEqualToString:@"Unlocked"])
    {
        self.statusLabel.text = @"Locked";
        [self toggleUpdates];
    }
    else
    {
        self.statusLabel.text = @"Unlocked";
        [self toggleUpdates];
    }
}
-(void)toggleUpdates
{
    if ([self.motionManager isDeviceMotionAvailable] && ![self.motionManager isDeviceMotionActive])
    {
        //[self.motionManager setDeviceMotionUpdateInterval:1.0/2.0];
        [self.motionManager startDeviceMotionUpdatesUsingReferenceFrame:CMAttitudeReferenceFrameXArbitraryCorrectedZVertical toQueue:[NSOperationQueue mainQueue] withHandler:^(CMDeviceMotion *motion, NSError *error)
         {
             int scale = 5.0;
             CGRect labelRect = self.statusLabel.frame;
             labelRect.origin.x += motion.gravity.x * scale;
             if (!CGRectContainsRect(self.view.bounds, labelRect))
             {
                 labelRect.origin.x = self.statusLabel.frame.origin.x;
             }
             labelRect.origin.y -= motion.gravity.y *scale;
             if (!CGRectContainsRect(self.view.bounds, labelRect))
             {
                 labelRect.origin.y = self.statusLabel.frame.origin.y;
             }
             [self.statusLabel setFrame:labelRect];
         }];
    }
    else if ([self.motionManager isDeviceMotionActive])
    {
        [self.motionManager stopDeviceMotionUpdates];
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(shakeDetected:) name:@"NOTIFICATION_SHAKE" object:nil];
    
    
}
- (void)viewDidUnload
{
    if ([self.motionManager isDeviceMotionAvailable] && [self.motionManager isDeviceMotionActive])
    {
        [self.motionManager stopDeviceMotionUpdates];
    }
    
    self.motionManager = nil;
    [self setXAccLabel:nil];
    [self setYAccLabel:nil];
    [self setZAccLabel:nil];
    [self setXGyroLabel:nil];
    [self setYGyroLabel:nil];
    [self setZGyroLabel:nil];
    [self setStatusLabel:nil];
    [self setXMagLabel:nil];
    [self setYMagLabel:nil];
    [self setZMagLabel:nil];
    [self setRollLabel:nil];
    [self setPitchLabel:nil];
    [self setYawLabel:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
