//
//  MainWindow.h
//  Measurements

#import <UIKit/UIKit.h>

@interface MainWindow : UIWindow

@end
