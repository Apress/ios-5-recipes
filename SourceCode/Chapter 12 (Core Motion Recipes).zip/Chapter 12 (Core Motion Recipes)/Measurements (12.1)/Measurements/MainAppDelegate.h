//
//  MainAppDelegate.h
//  Measurements

#import <UIKit/UIKit.h>
#import "MainWindow.h"

@class MainViewController;

@interface MainAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) MainViewController *viewController;

@end
