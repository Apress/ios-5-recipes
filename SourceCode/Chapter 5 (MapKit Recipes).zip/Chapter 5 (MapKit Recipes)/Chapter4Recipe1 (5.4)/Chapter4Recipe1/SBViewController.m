//
//  SBViewController.m
//  Chapter4Recipe1

#import "SBViewController.h"

@implementation SBViewController
@synthesize mapViewUserMap;
@synthesize labelUserLocation;
@synthesize toolbarMapTools;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation{
    self.labelUserLocation.text=
    [NSString 
     stringWithFormat:@"Current Location: %.5f°, %.5f°", 
     userLocation.coordinate.latitude,
     userLocation.coordinate.longitude];
}
-(MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id )overlay{
    if([overlay isKindOfClass:[MKPolygon class]]){
        MKPolygonView *view = [[MKPolygonView alloc] initWithOverlay:overlay];
        
        //Display settings
        view.lineWidth=1;
        view.strokeColor=[UIColor blueColor];
        view.fillColor=[[UIColor blueColor] colorWithAlphaComponent:0.5];
        return view;
    }
    else if ([overlay isKindOfClass:[MKPolyline class]])
    {
        MKPolylineView *view = [[MKPolylineView alloc] initWithOverlay:overlay];
        
        //Display settings
        view.lineWidth = 3;
        view.strokeColor = [UIColor blueColor];
        return view;
    }
    return nil;
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Set MKMapView delegate
    self.mapViewUserMap.delegate=self;
    
    //Set MKMapView starting region
    CLLocationCoordinate2D coordinateBaltimore = CLLocationCoordinate2DMake(39.303, -76.612);
    self.mapViewUserMap.region=
    MKCoordinateRegionMakeWithDistance(coordinateBaltimore, 
                                       10000, 
                                       10000);
    
    //Optional Controls
    //    self.mapViewUserMap.zoomEnabled=NO;
    //    self.mapViewUserMap.scrollEnabled=NO;
    
    //Control User Location on Map
    if ([CLLocationManager locationServicesEnabled])
    {
        mapViewUserMap.showsUserLocation = YES;
        [mapViewUserMap setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
    }
    
    //Create BarButtonItem for controller user location tracking
    MKUserTrackingBarButtonItem *trackingBarButton =
    [[MKUserTrackingBarButtonItem alloc] initWithMapView:self.mapViewUserMap];
    
    //Add UserTrackingBarButtonItem to UIToolbar
    [self.toolbarMapTools 
     setItems:[NSArray arrayWithObject:trackingBarButton] 
     animated:YES];
    
    //Create and Add Overlays
    NSMutableArray *overlays = [[NSMutableArray alloc] initWithCapacity:2];
    CLLocationCoordinate2D polyCoords[5]={
        CLLocationCoordinate2DMake(39.9, -76.6),
        CLLocationCoordinate2DMake(36.7, -84.0),
        CLLocationCoordinate2DMake(33.1, -89.4),
        CLLocationCoordinate2DMake(27.3, -80.8),
        CLLocationCoordinate2DMake(39.9, -76.6)
    };
    MKPolygon *Poly = [MKPolygon polygonWithCoordinates:polyCoords count:5];
    [overlays addObject:Poly];
    CLLocationCoordinate2D pathCoords[2] = {
        CLLocationCoordinate2DMake(46.8, -100.8),
        CLLocationCoordinate2DMake(43.7, -70.4)
    };
    MKPolyline *pathLine = [MKPolyline polylineWithCoordinates:pathCoords count:2];
    [overlays addObject:pathLine];
    [self.mapViewUserMap addOverlays:overlays];

}

- (void)viewDidUnload
{
    self.mapViewUserMap.delegate=nil;
    [self setMapViewUserMap:nil];
    [self setLabelUserLocation:nil];
    [self setToolbarMapTools:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
