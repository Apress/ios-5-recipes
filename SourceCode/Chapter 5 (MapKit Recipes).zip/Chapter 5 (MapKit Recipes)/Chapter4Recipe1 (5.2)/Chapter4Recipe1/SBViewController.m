//
//  SBViewController.m
//  Chapter4Recipe1

#import "SBViewController.h"

@implementation SBViewController
@synthesize mapViewUserMap;
@synthesize labelUserLocation;
@synthesize toolbarMapTools;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation{
    self.labelUserLocation.text=
    [NSString 
     stringWithFormat:@"Current Location: %.5f°, %.5f°", 
     userLocation.coordinate.latitude,
     userLocation.coordinate.longitude];
}
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MyAnnotation class]]) //Ensures the User's location is not affected.
    {
        static NSString *annotationIdentifier=@"annotationIdentifier";
        //Try to get an unused annotation, similar to uitableviewcells
        MKAnnotationView *annotationView=[self.mapViewUserMap dequeueReusableAnnotationViewWithIdentifier:annotationIdentifier];
        annotationView.annotation = annotation;
        //If one isn't available, create a new one
        if(!annotationView)
        {
            annotationView=[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:annotationIdentifier];
        }
        
        //Optional properties to change
        annotationView.canShowCallout = YES;
        annotationView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure]; //Creates button on right of callout
        annotationView.draggable = YES;
        return annotationView;
    }
    return nil;
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Set MKMapView delegate
    self.mapViewUserMap.delegate=self;
    
    //Set MKMapView starting region
    CLLocationCoordinate2D coordinateBaltimore = CLLocationCoordinate2DMake(39.303, -76.612);
    self.mapViewUserMap.region=
    MKCoordinateRegionMakeWithDistance(coordinateBaltimore, 
                                       10000, 
                                       10000);
    
    //Optional Controls
    //    self.mapViewUserMap.zoomEnabled=NO;
    //    self.mapViewUserMap.scrollEnabled=NO;
    
    //Control User Location on Map
    if ([CLLocationManager locationServicesEnabled])
    {
        mapViewUserMap.showsUserLocation = YES;
        [mapViewUserMap setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
    }
    
    //Create BarButtonItem for controller user location tracking
    MKUserTrackingBarButtonItem *trackingBarButton =
    [[MKUserTrackingBarButtonItem alloc] initWithMapView:self.mapViewUserMap];
    
    //Add UserTrackingBarButtonItem to UIToolbar
    [self.toolbarMapTools 
     setItems:[NSArray arrayWithObject:trackingBarButton] 
     animated:YES];
    
    //Create and add Annotations
    NSMutableArray *annotations = [[NSMutableArray alloc] initWithCapacity:2];    
    MyAnnotation *ann1 = [[MyAnnotation alloc] initWithCoordinate:CLLocationCoordinate2DMake(25.802, -80.132)];
    ann1.title = @"Miami";
    ann1.subtitle = @"Annotation1";
    MyAnnotation *ann2 = [[MyAnnotation alloc] initWithCoordinate:CLLocationCoordinate2DMake(39.733, -105.018)];
    ann2.title = @"Denver";
    ann2.subtitle = @"Annotation2";    
    [annotations addObject:ann1];
    [annotations addObject:ann2];
    
    [self.mapViewUserMap addAnnotations:annotations];

}

- (void)viewDidUnload
{
    self.mapViewUserMap.delegate=nil;
    [self setMapViewUserMap:nil];
    [self setLabelUserLocation:nil];
    [self setToolbarMapTools:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
