//
//  SBViewController.h
//  Chapter4Recipe1

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "MyAnnotation.h"

@interface SBViewController : UIViewController <MKMapViewDelegate> {
    MKMapView *mapViewUserMap;
    UILabel *labelUserLocation;
}

@property (strong, nonatomic) IBOutlet MKMapView *mapViewUserMap;
@property (strong, nonatomic) IBOutlet UILabel *labelUserLocation;
@property (strong, nonatomic) IBOutlet UIToolbar *toolbarMapTools;

@end
