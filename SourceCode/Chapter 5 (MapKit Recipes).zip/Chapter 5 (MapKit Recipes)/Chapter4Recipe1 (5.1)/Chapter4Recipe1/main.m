//
//  main.m
//  Chapter4Recipe1

#import <UIKit/UIKit.h>

#import "SBAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([SBAppDelegate class]));
    }
}
