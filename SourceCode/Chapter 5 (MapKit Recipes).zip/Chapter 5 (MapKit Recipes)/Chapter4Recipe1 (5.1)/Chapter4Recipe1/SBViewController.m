//
//  SBViewController.m
//  Chapter4Recipe1

#import "SBViewController.h"

@implementation SBViewController
@synthesize mapViewUserMap;
@synthesize labelUserLocation;
@synthesize toolbarMapTools;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation{
    self.labelUserLocation.text=
    [NSString 
     stringWithFormat:@"Current Location: %.5f°, %.5f°", 
     userLocation.coordinate.latitude,
     userLocation.coordinate.longitude];
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //Set MKMapView delegate
    self.mapViewUserMap.delegate=self;
    
    //Set MKMapView starting region
    CLLocationCoordinate2D coordinateBaltimore = CLLocationCoordinate2DMake(39.303, -76.612);
    self.mapViewUserMap.region=
    MKCoordinateRegionMakeWithDistance(coordinateBaltimore, 
                                       10000, 
                                       10000);
    
    //Optional Controls
    //    self.mapViewUserMap.zoomEnabled=NO;
    //    self.mapViewUserMap.scrollEnabled=NO;
    
    //Control User Location on Map
    if ([CLLocationManager locationServicesEnabled])
    {
        mapViewUserMap.showsUserLocation = YES;
        [mapViewUserMap setUserTrackingMode:MKUserTrackingModeFollow animated:YES];
    }
    
    //Create BarButtonItem for controller user location tracking
    MKUserTrackingBarButtonItem *trackingBarButton =
    [[MKUserTrackingBarButtonItem alloc] initWithMapView:self.mapViewUserMap];
    
    //Add UserTrackingBarButtonItem to UIToolbar
    [self.toolbarMapTools 
     setItems:[NSArray arrayWithObject:trackingBarButton] 
     animated:YES];

}

- (void)viewDidUnload
{
    self.mapViewUserMap.delegate=nil;
    [self setMapViewUserMap:nil];
    [self setLabelUserLocation:nil];
    [self setToolbarMapTools:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
