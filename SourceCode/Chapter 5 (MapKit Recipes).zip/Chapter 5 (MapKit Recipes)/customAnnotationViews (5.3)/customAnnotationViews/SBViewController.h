//
//  SBViewController.h
//  customAnnotationViews

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "MyAnnotation.h"
#import "CustomAnnotationView.h"
#import "DetailViewController.h"

@interface SBViewController : UIViewController <MKMapViewDelegate>
@property (strong, nonatomic) IBOutlet MKMapView *mapViewUserMap;

@end
