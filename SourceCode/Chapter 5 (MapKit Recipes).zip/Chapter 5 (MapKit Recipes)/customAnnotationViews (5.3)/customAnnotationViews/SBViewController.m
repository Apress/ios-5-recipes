//
//  SBViewController.m
//  customAnnotationViews

#import "SBViewController.h"

@implementation SBViewController
@synthesize mapViewUserMap;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)view calloutAccessoryControlTapped:(UIControl *)control
{
    MyAnnotation *ann = view.annotation;
    DetailViewController *dvc = [[DetailViewController alloc] initWithTitle:ann.title subtitle:ann.subtitle];
    dvc.modalTransitionStyle = UIModalTransitionStylePartialCurl;
    [self presentViewController:dvc animated:YES completion:^{}];
}
- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MyAnnotation class]]) 
    {
        static NSString *annotationIdentifier=@"annotationIdentifier";
        MKAnnotationView *annotationView=[self.mapViewUserMap dequeueReusableAnnotationViewWithIdentifier:annotationIdentifier];
        annotationView.annotation = annotation;
        if(!annotationView)
        {
            annotationView=[[CustomAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:annotationIdentifier];
        }
        
        annotationView.canShowCallout = YES;
        return annotationView;
    }
    return nil;
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.mapViewUserMap.delegate = self;
    
    MyAnnotation *test1 = [[MyAnnotation alloc] initWithCoordinate:CLLocationCoordinate2DMake(37.68, -97.33)];
    test1.title = @"test1";
    test1.subtitle = @"subtitle"; 
    MyAnnotation *test2 = [[MyAnnotation alloc] initWithCoordinate:CLLocationCoordinate2DMake(41.500, -81.695)];
    test2.title = @"test2";
    test2.subtitle = @"subtitle2";
    [self.mapViewUserMap addAnnotation:test1];
    [self.mapViewUserMap addAnnotation:test2];

}

- (void)viewDidUnload
{
    [self setMapViewUserMap:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
