//
//  CustomAnnotationView.h
//  customAnnotationViews

#import <MapKit/MapKit.h>

@interface CustomAnnotationView : MKAnnotationView
-(id)initWithAnnotation:(id <MKAnnotation>) annotation reuseIdentifier:(NSString *)annotationIdentifier;
@end
