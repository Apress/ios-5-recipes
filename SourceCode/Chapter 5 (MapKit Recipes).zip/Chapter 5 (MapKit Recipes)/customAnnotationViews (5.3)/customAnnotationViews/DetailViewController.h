//
//  DetailViewController.h
//  customAnnotationViews

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController {
    UILabel *titleLabel;
    UILabel *subtitleLabel;
    NSString *myTitle;
    NSString *mySubtitle;
}

@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) IBOutlet UILabel *subtitleLabel;

-(id)initWithTitle:(NSString *)title subtitle:(NSString *)subtitle;
@end

