//
//  DetailViewController.m
//  customAnnotationViews

#import "DetailViewController.h"

@implementation DetailViewController
@synthesize titleLabel;
@synthesize subtitleLabel;

-(id)initWithTitle:(NSString *)title subtitle:(NSString *)subtitle
{
    self = [super init];
    if (self)
    {
        myTitle = title;
        mySubtitle = subtitle;
    }
    return self;
}


- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.titleLabel.text = myTitle;
    self.subtitleLabel.text = mySubtitle;
}

- (void)viewDidUnload
{
    [self setTitleLabel:nil];
    [self setSubtitleLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
