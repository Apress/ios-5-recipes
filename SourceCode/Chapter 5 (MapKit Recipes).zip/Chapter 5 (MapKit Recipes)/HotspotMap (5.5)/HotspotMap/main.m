//
//  main.m
//  HotspotMap

#import <UIKit/UIKit.h>

#import "CSDAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CSDAppDelegate class]));
    }
}
