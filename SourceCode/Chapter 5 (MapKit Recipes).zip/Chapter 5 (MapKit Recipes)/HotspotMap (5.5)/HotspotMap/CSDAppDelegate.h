//
//  CSDAppDelegate.h
//  HotspotMap

#import <UIKit/UIKit.h>

@class CSDViewController;

@interface CSDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) CSDViewController *viewController;

@end
