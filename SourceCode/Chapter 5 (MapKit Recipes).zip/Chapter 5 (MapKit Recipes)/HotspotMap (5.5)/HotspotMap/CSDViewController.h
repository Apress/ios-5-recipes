//
//  CSDViewController.h
//  HotspotMap

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

#import "Hotspot.h"

@interface CSDViewController : UIViewController <MKMapViewDelegate>
{
    MKMapView *mapViewUserMap;
    CLLocationDegrees zoom;
}

@property (strong, nonatomic) IBOutlet MKMapView *mapViewUserMap;
@property (strong, nonatomic) NSMutableArray *places;

@end
