//
//  Hotspot.m
//  HotspotMap

#import "Hotspot.h"

@implementation Hotspot
@synthesize coordinate, title, subtitle;
@synthesize places, annotationView;
-(id)initWithCoordinate:(CLLocationCoordinate2D) c
{
    self=[super init];
    if(self){
        coordinate = c;
        self.places = [[NSMutableArray alloc] initWithCapacity:0];
    }
    return self;
}
-(NSString *)title
{
    if ([self placesCount] == 1)
    {
        return title;
    }
    else
        return [NSString stringWithFormat:@"%i Places", [self.places count]];
}
-(void)addPlace:(Hotspot *)hotspot
{
    [self.places addObject:hotspot];
}
-(int)placesCount{
    return [self.places count];
}
-(void)cleanPlaces{
    [self.places removeAllObjects];
    [self.places addObject:self];
}
@end
