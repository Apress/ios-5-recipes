//
//  CSDViewController.m
//  HotspotMap

#define centerLat  39.2953 
#define centerLong -76.614
#define spanDeltaLat    4.9
#define spanDeltaLong   5.8
#define scaleLat  9.0    
#define scaleLong  11.0

#import "CSDViewController.h"

@implementation CSDViewController
@synthesize mapViewUserMap, places;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

-(void)group:(NSArray *)hotspots{
    float latDelta=self.mapViewUserMap.region.span.latitudeDelta/scaleLat;
    float longDelta=self.mapViewUserMap.region.span.longitudeDelta/scaleLong;
    //New lines:
    [hotspots makeObjectsPerformSelector:@selector(cleanPlaces)];
    //End of new lines.
    NSMutableArray *visibleHotspots=[[NSMutableArray alloc] initWithCapacity:0];
    
    for (Hotspot *current in hotspots) {
        CLLocationDegrees lat = current.coordinate.latitude;
        CLLocationDegrees longi = current.coordinate.longitude;
        bool found=FALSE;
        for (Hotspot *tempHotspot in visibleHotspots) {
            if(fabs(tempHotspot.coordinate.latitude-lat) < latDelta && fabs(tempHotspot.coordinate.longitude-longi)<longDelta ){
                [self.mapViewUserMap removeAnnotation:current];
                found=TRUE;
                //New lines:
                [tempHotspot addPlace:current];
                //End of new lines.
                break;
            }
        }
        if (!found) {
            [visibleHotspots addObject:current];
            [self.mapViewUserMap addAnnotation:current];
        }
    }
}
-(void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated{
    if (zoom!=mapView.region.span.longitudeDelta) {     
        [self group:places];
        zoom=mapView.region.span.longitudeDelta;
        //NEW CODE
        NSSet *visibleAnnotations = [mapView annotationsInMapRect:mapView.visibleMapRect];
        for (Hotspot *place in visibleAnnotations)
        {
            if ([place placesCount] > 1)
                place.annotationView.pinColor = MKPinAnnotationColorGreen;
            else
                place.annotationView.pinColor = MKPinAnnotationColorRed;
        }
        //END OF NEW CODE
    }
}

- (MKAnnotationView *)mapView:(MKMapView *)mV viewForAnnotation:(id <MKAnnotation>)annotation{
	
    // if it's the user location, just return nil.
    if ([annotation isKindOfClass:[MKUserLocation class]]){
        return nil;
    }
	else{        
        static NSString *StartPinIdentifier = @"PinIdentifier";
        MKPinAnnotationView *startPin = (id)[mV dequeueReusableAnnotationViewWithIdentifier:StartPinIdentifier];
		if (startPin == nil) {
            startPin = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:StartPinIdentifier];       
        }
        startPin.canShowCallout = YES; 
        startPin.animatesDrop = YES;
        //NEW CODE
        Hotspot *place = annotation;
        place.annotationView = startPin;
        if ([place placesCount] > 1)
        {
            startPin.pinColor = MKPinAnnotationColorGreen;
        }
        else if ([place placesCount] == 1)
        {
            startPin.pinColor = MKPinAnnotationColorRed;
        }
        //END OF NEW CODE
        return startPin;
	}   
}

-(NSMutableArray *)places
{
    if (!places)
    {
        places = [[NSMutableArray alloc] initWithCapacity:1000];
    }
    return places;
}
-(float)RandomFloatStart:(float)a end:(float)b
{
    float random = ((float) rand()) / (float) RAND_MAX;
    float diff = b - a;
    float r = random * diff;
    return a + r;
}
-(void)loadDummyPlaces
{
    srand((unsigned)time(0));
    
    for (int i=0; i<1000; i++)
    {
        Hotspot *place=[[Hotspot alloc] initWithCoordinate:CLLocationCoordinate2DMake([self RandomFloatStart:37.0 end:42.0],[self RandomFloatStart:-72.0 end:-79.0])];
        place.title = [NSString stringWithFormat:@"Place %d title",i];
        place.subtitle = [NSString stringWithFormat:@"Place %d subtitle",i];
        [self.places addObject:place];
    }
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.mapViewUserMap.delegate = self;
    [self loadDummyPlaces];
    //[self.mapViewUserMap addAnnotations:self.places]; //For setup purposes only. This line will be unnecessary        when grouping is implemented.
    CLLocationCoordinate2D centerPoint = {centerLat, centerLong};
	MKCoordinateSpan coordinateSpan = MKCoordinateSpanMake(spanDeltaLat, spanDeltaLong);
	MKCoordinateRegion coordinateRegion = MKCoordinateRegionMake(centerPoint, coordinateSpan);
    
	[self.mapViewUserMap setRegion:coordinateRegion];
	[self.mapViewUserMap regionThatFits:coordinateRegion];
}

- (void)viewDidUnload
{
    [self.places removeAllObjects];
    self.places = nil;
    [self setMapViewUserMap:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
