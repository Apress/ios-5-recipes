//
//  MyView.h
//  ShapesAndSizes

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>

@interface MyView : UIView
@property (nonatomic, strong) UIImage *image;
@end
