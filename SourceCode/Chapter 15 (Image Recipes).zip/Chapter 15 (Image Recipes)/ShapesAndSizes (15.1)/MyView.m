//
//  MyView.m
//  ShapesAndSizes

#import "MyView.h"

@implementation MyView
@synthesize image;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)drawRect:(CGRect)rect
{
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGRect drawingRect = CGRectMake(0.0, 20.0f, 100.0f, 180.0f);
    const CGFloat *rectColorComponents = CGColorGetComponents([[UIColor greenColor] CGColor]);
    CGContextSetFillColor(context, rectColorComponents);
    CGContextFillRect(context, drawingRect);
    
    CGRect ellipseRect = CGRectMake(140.0f, 200.0f, 75.0f, 50.0f);
    const CGFloat *ellipseColorComponenets = CGColorGetComponents([[UIColor blueColor] CGColor]);
    CGContextSetFillColor(context, ellipseColorComponenets);
    CGContextFillEllipseInRect(context, ellipseRect);
    
    CGContextBeginPath(context);
    CGContextMoveToPoint(context, 0.0f, 0.0f);
    CGContextAddLineToPoint(context, 100.0f, 0.0f);
    CGContextAddLineToPoint(context, 140.0f, 100.0f);
    CGContextAddLineToPoint(context, 40.0f, 100.0f);
    CGContextClosePath(context);
    CGContextSetGrayFillColor(context, 0.4f, 0.85f);
    CGContextSetGrayStrokeColor(context, 0.0, 0.0);
    CGContextFillPath(context);
    
    if (self.image)
    {
        CGRect imageRect = CGRectMake(200.0f, 50.0f, 100.0f, 300.0f);
        [image drawInRect:imageRect];
    }

}

@end
