//
//  MainViewController.h
//  ShapesAndSizes

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <CoreGraphics/CoreGraphics.h>
#import "MyView.h"

@interface MainViewController : UIViewController
@property (strong, nonatomic) IBOutlet MyView *customView;
- (IBAction)snapshotPressed:(id)sender;

@end
