//
//  MainAppDelegate.h
//  ImageRecipes

#import <UIKit/UIKit.h>

@interface MainAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UISplitViewController *splitViewController;

@end
