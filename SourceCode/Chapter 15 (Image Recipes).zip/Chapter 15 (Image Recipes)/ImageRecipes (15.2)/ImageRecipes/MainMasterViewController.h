//
//  MainMasterViewController.h
//  ImageRecipes

#import <UIKit/UIKit.h>

@class MainDetailViewController;

@interface MainMasterViewController : UITableViewController

@property (strong, nonatomic) MainDetailViewController *detailViewController;

@end
