//
//  MainMasterViewController.h
//  ImageRecipes

#import <UIKit/UIKit.h>
#import <CoreImage/CoreImage.h>

@class MainDetailViewController;

@interface MainMasterViewController : UITableViewController

@property (strong, nonatomic) MainDetailViewController *detailViewController;

@property (strong, nonatomic) UIImage *mainImage;

@property (strong, nonatomic) NSMutableArray *images;

@end
