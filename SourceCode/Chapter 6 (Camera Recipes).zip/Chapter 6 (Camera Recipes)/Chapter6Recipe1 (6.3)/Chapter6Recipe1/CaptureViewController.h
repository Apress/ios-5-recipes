//
//  CaptureViewController.h
//  Chapter6Recipe1

#import <UIKit/UIKit.h>
#import <MobileCoreServices/MobileCoreServices.h>

@interface CaptureViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIVideoEditorControllerDelegate>
{
    UIImageView *imageViewRecent;
    UIButton *cameraButton;
}

@property (strong, nonatomic) IBOutlet UIImageView *imageViewRecent;
@property (strong, nonatomic) IBOutlet UIButton *cameraButton;
@property (nonatomic, strong) NSString *recentMovie;
- (IBAction)editButtonPressed:(id)sender;

-(IBAction)cameraButtonPressed:(id)sender;
@end
