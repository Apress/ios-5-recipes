//
//  CustomVideoViewController.h
//  Chapter6Recipe6

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>

@interface CustomVideoViewController : UIViewController <AVCaptureFileOutputRecordingDelegate>{
    UIButton *button;
    BOOL recording;
}

@property (strong, nonatomic) IBOutlet UIButton *button;

@property (strong, nonatomic) AVCaptureSession *session;
@property (strong, nonatomic) AVCaptureMovieFileOutput *output;
@property (strong, nonatomic) IBOutlet UIImageView *imageViewThumb;
@property (strong, nonatomic) IBOutlet UIImageView *imageViewThumb2;

-(IBAction)recordPressed:(id)sender;

@property (strong, nonatomic) AVCaptureStillImageOutput *stillImageOutput;
@property (strong, nonatomic) AVAssetImageGenerator *imageGenerator;
@end
