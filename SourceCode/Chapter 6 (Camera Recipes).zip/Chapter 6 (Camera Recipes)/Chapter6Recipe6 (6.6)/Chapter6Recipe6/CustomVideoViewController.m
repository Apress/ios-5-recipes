//
//  CustomVideoViewController.m
//  Chapter6Recipe6

#import "CustomVideoViewController.h"

@implementation CustomVideoViewController
@synthesize button, session, output;
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
- (void)captureOutput:(AVCaptureFileOutput *)captureOutput
didFinishRecordingToOutputFileAtURL:(NSURL *)outputFileURL
      fromConnections:(NSArray *)connections
                error:(NSError *)error {
    
    BOOL recordedSuccessfully = YES;
    if ([error code] != noErr) {
        // A problem occurred: Find out if the recording was successful.
        id value = [[error userInfo] objectForKey:AVErrorRecordingSuccessfullyFinishedKey];
        if (value) {
            recordedSuccessfully = [value boolValue];
        }
    }
    ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    
    [library writeVideoAtPathToSavedPhotosAlbum:outputFileURL
                                completionBlock:^(NSURL *assetURL, NSError *error)
     {
         if (error) 
         {
             NSLog(@"Error writing") ;                      
         }
         
     }];
}
- (NSURL *) tempFileURL
{
    NSString *outputPath = [[NSString alloc] initWithFormat:@"%@%@", NSTemporaryDirectory(), @"output.mov"];
    NSURL *outputURL = [[NSURL alloc] initFileURLWithPath:outputPath];
    NSFileManager *manager = [[NSFileManager alloc] init];
    if ([manager fileExistsAtPath:outputPath])
    {
        [manager removeItemAtPath:outputPath error:nil];
    }
    return outputURL;
}
#pragma mark - View lifecycle
-(IBAction)recordPressed:(id)sender
{
    if (!recording)
    {
        [self.button setTitle:@"Stop" forState:UIControlStateNormal];
        recording = YES;
        NSURL *fileURL = [self tempFileURL];
        [self.output startRecordingToOutputFileURL:fileURL recordingDelegate:self]; 
    }
    else
    {
        [self.button setTitle:@"Record" forState:UIControlStateNormal];
        [self.output stopRecording];
        recording = NO;
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.session = [[AVCaptureSession alloc] init];
    self.session.sessionPreset = AVCaptureSessionPresetMedium;
    
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    
    NSError *error = nil;
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:&error];
    
    NSArray *devices = [AVCaptureDevice devicesWithMediaType:AVMediaTypeAudio];
    
    AVCaptureDeviceInput *mic = [[AVCaptureDeviceInput alloc] initWithDevice:[devices objectAtIndex:0] error:nil];
    
    if (!input || !mic)
    {
        NSLog(@"Input Error");
    }
    else
    {
        [self.session addInput:input];
        [self.session addInput:mic];
    }
    
    self.output = [[AVCaptureMovieFileOutput alloc] init];
    
    NSArray *connections = self.output.connections;
    for (AVCaptureConnection *connection in connections)
    {
        if ([connection isVideoOrientationSupported])
            connection.videoOrientation = AVCaptureVideoOrientationPortrait;
    }
    if ([self.session canAddOutput:self.output])
        [self.session addOutput:self.output];
    
    AVCaptureVideoPreviewLayer *previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:self.session];
    UIView *aView = self.view;
    previewLayer.frame = CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height-70); 
    [aView.layer addSublayer:previewLayer];
    
    [self.session startRunning];
    recording = NO;
}

- (void)viewDidUnload
{
    self.button = nil;
    self.session = nil;
    self.output = nil;
    [super viewDidUnload];
   
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (![self.session isRunning])
    {
        [self.session startRunning];
    }
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if ([self.session isRunning])
    {
        [self.session stopRunning];
    }
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}


- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
