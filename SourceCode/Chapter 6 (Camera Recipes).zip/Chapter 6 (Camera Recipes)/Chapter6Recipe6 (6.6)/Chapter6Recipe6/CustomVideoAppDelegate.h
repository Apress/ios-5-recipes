//
//  CustomVideoAppDelegate.h
//  Chapter6Recipe6

#import <UIKit/UIKit.h>

@class CustomVideoViewController;

@interface CustomVideoAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) CustomVideoViewController *viewController;

@end
