//
//  CustomVideoViewController.h
//  Chapter6Recipe6

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>

@interface CustomVideoViewController : UIViewController <AVCaptureFileOutputRecordingDelegate>{
    UIButton *button;
    BOOL recording;
}

@property (strong, nonatomic) IBOutlet UIButton *button;

@property (strong, nonatomic) AVCaptureSession *session;
@property (strong, nonatomic) AVCaptureMovieFileOutput *output;

-(IBAction)recordPressed:(id)sender;
@end
