//
//  CaptureViewController.m
//  Chapter6Recipe1

#import "CaptureViewController.h"
#import <MobileCoreServices/MobileCoreServices.h>

@implementation CaptureViewController
@synthesize imageViewRecent;
@synthesize cameraButton;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
// For responding to the user tapping Cancel.
- (void) imagePickerControllerDidCancel: (UIImagePickerController *) picker 
{
    [self dismissModalViewControllerAnimated:YES];
}
-(void)toggleFlash:(UIButton *)sender
{
    if (flashOn)
    {
        currentPicker.cameraFlashMode = UIImagePickerControllerCameraFlashModeOff;
        flashOn = NO;
        [sender setTitle:@"Flash Off" forState:UIControlStateNormal];
    }
    else
    {
        currentPicker.cameraFlashMode = UIImagePickerControllerCameraFlashModeOn;
        flashOn = YES;
        [sender setTitle:@"Flash On" forState:UIControlStateNormal];
    }
}
-(void)toggleCamera:(UIButton *)sender
{
    if (frontCameraUsed)
    {
        currentPicker.cameraDevice = UIImagePickerControllerCameraDeviceRear;    
        frontCameraUsed = NO;
        [sender setTitle:@"Rear Camera" forState:UIControlStateNormal];
    }
    else
    {
        currentPicker.cameraDevice = UIImagePickerControllerCameraDeviceFront;
        frontCameraUsed = YES;
        [sender setTitle:@"Front Camera" forState:UIControlStateNormal];
    }
}
-(UIView *)customView:(UIImagePickerController *)imagePicker;
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 280, 480)];
    view.backgroundColor = [UIColor clearColor];
    
    UIButton *flashButton = [[UIButton alloc] initWithFrame:CGRectMake(10, 10, 120, 44)];
    flashButton.backgroundColor = [UIColor colorWithRed:.5 green:.5 blue:.5 alpha:.5];
    [flashButton setTitle:@"Flash Auto" forState:UIControlStateNormal];
    [flashButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    flashButton.layer.cornerRadius = 10.0;
    
    UIButton *changeCameraButton = [[UIButton alloc] initWithFrame:CGRectMake(190, 10, 120, 44)];
    changeCameraButton.backgroundColor = [UIColor colorWithRed:.5 green:.5 blue:.5 alpha:.5];
    [changeCameraButton setTitle:@"Rear Camera" forState:UIControlStateNormal];
    [changeCameraButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    changeCameraButton.layer.cornerRadius = 10.0;
    
    UIButton *takePictureButton = [[UIButton alloc] initWithFrame:CGRectMake(100, 432, 120, 44)];
    takePictureButton.backgroundColor = [UIColor colorWithRed:.5 green:.5 blue:.5 alpha:.5];
    [takePictureButton setTitle:@"Click!" forState:UIControlStateNormal];
    [takePictureButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    takePictureButton.layer.cornerRadius = 10.0;
    
    [flashButton addTarget:self action:@selector(toggleFlash:) forControlEvents:UIControlEventTouchUpInside];
    [changeCameraButton addTarget:self action:@selector(toggleCamera:) forControlEvents:UIControlEventTouchUpInside];
    [takePictureButton addTarget:imagePicker action:@selector(takePicture) forControlEvents:UIControlEventTouchUpInside];
    
    [view addSubview:flashButton];
    [view addSubview:changeCameraButton];
    [view addSubview:takePictureButton];
    
    return view;
}


// For responding to the user accepting a newly-captured picture or movie
- (void) imagePickerController: (UIImagePickerController *) picker
 didFinishPickingMediaWithInfo: (NSDictionary *) info
{
    NSString *mediaType = [info objectForKey: UIImagePickerControllerMediaType];
    
    if (CFStringCompare ((__bridge CFStringRef) mediaType, kUTTypeMovie, 0)
        == kCFCompareEqualTo) {
        
        NSString *moviePath = [[info objectForKey: UIImagePickerControllerMediaURL] path];        
        if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum (moviePath))
        {
            UISaveVideoAtPathToSavedPhotosAlbum (moviePath, nil, nil, nil);
        }
    }
    
    else
    {
        UIImage *originalImage = (UIImage *) [info objectForKey:
                                              UIImagePickerControllerOriginalImage];
        
        UIImageWriteToSavedPhotosAlbum (originalImage, nil, nil , nil);
        self.imageViewRecent.image = originalImage;
    }
    currentPicker = nil;
    [self dismissModalViewControllerAnimated:YES];
}

-(IBAction)cameraButtonPressed:(id)sender
{
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera] == NO)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Camera Unavailable" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:nil, nil];
        [alert show];
        return;
    }
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    currentPicker = imagePicker;
    imagePicker.delegate = self;
    imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    imagePicker.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera];
    imagePicker.showsCameraControls = NO;
    imagePicker.cameraOverlayView = [self customView:imagePicker];
    [self presentModalViewController:imagePicker animated:YES];
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    self.imageViewRecent.backgroundColor = [UIColor lightGrayColor];
}

- (void)viewDidUnload
{
    [self setImageViewRecent:nil];
    [self setCameraButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (YES);
}

@end
