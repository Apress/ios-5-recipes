//
//  CaptureAppDelegate.h
//  Chapter6Recipe1


#import <UIKit/UIKit.h>

@class CaptureViewController;

@interface CaptureAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) CaptureViewController *viewController;

@end
