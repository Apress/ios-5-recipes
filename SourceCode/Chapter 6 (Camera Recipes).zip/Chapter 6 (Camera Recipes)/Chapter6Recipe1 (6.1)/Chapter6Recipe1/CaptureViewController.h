//
//  CaptureViewController.h
//  Chapter6Recipe1

#import <UIKit/UIKit.h>

@interface CaptureViewController : UIViewController <UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    UIImageView *imageViewRecent;
    UIButton *cameraButton;
}

@property (strong, nonatomic) IBOutlet UIImageView *imageViewRecent;
@property (strong, nonatomic) IBOutlet UIButton *cameraButton;

-(IBAction)cameraButtonPressed:(id)sender;
@end
