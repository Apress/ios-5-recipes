//
//  main.m
//  Chapter6Recipe5

#import <UIKit/UIKit.h>

#import "CustomCameraAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CustomCameraAppDelegate class]));
    }
}
