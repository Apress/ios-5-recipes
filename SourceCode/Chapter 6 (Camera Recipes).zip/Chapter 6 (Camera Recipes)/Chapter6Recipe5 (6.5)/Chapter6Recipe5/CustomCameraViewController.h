//
//  CustomCameraViewController.h
//  Chapter6Recipe5

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AVFoundation/AVCaptureInput.h>

@interface CustomCameraViewController : UIViewController <AVCaptureVideoDataOutputSampleBufferDelegate>{
    UIButton *startButton;
    BOOL capture;
}

@property (strong, nonatomic) IBOutlet UIButton *startButton;
@property (strong, nonatomic) AVCaptureSession *captureSession;
-(IBAction)startPressed:(id)sender;

@end
