//
//  CustomCameraAppDelegate.h
//  Chapter6Recipe5

#import <UIKit/UIKit.h>

@class CustomCameraViewController;

@interface CustomCameraAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) CustomCameraViewController *viewController;

@end
