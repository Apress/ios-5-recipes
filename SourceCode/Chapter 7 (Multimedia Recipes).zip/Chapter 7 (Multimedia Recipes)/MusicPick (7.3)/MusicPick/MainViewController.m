//
//  MainViewController.m
//  MPMediaPickerController Test

#import "MainViewController.h"

@implementation MainViewController
@synthesize queueButton;
@synthesize prevButton;
@synthesize playButton;
@synthesize nextButton;
@synthesize textFieldArtist;
@synthesize sliderVolume;
@synthesize infoLabel;
@synthesize player;
@synthesize myCollection;
@synthesize infoCenter;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
-(void)volumeChangedHardware:(id)sender
{
    [self.sliderVolume setValue:self.player.volume animated:YES];
}

- (void) handle_PlaybackStateChanged: (id) notification
{
    MPMusicPlaybackState playbackState = [self.player playbackState];
    
    if (playbackState == MPMusicPlaybackStateStopped) 
    {
        [self.playButton setTitle:@"Play" forState:UIControlStateNormal];
        self.infoLabel.text = @"...";
        [self.player stop];
    }
    else if (playbackState == MPMusicPlaybackStatePaused)
    {
        [self.playButton setTitle:@"Play" forState:UIControlStateNormal];
    }
    else if (playbackState == MPMusicPlaybackStatePlaying)
    {
        [self.playButton setTitle:@"Pause" forState:UIControlStateNormal];
    }
}
- (void) handle_NowPlayingItemChanged: (id) notification 
{
    MPMediaItem *currentItemPlaying = [self.player nowPlayingItem];
    if (currentItemPlaying)
    {
        NSString *info = [NSString stringWithFormat:@"%@ - %@", [currentItemPlaying valueForProperty:MPMediaItemPropertyTitle], [currentItemPlaying valueForProperty:MPMediaItemPropertyArtist]];
        self.infoLabel.text = info;
    }
    else
    {
        self.infoLabel.text = @"...";
    }
    if (self.player.playbackState == MPMusicPlaybackStatePlaying)
    {
        [self.playButton setTitle:@"Pause" forState:UIControlStateNormal];
    }
}

-(void)setNotifications
{
    NSNotificationCenter *notificationCenter = [NSNotificationCenter defaultCenter];
    
    [notificationCenter
     addObserver: self
     selector:    @selector (handle_NowPlayingItemChanged:)
     name:        MPMusicPlayerControllerNowPlayingItemDidChangeNotification
     object:      self.player];
    
    [notificationCenter
     addObserver: self
     selector:    @selector (handle_PlaybackStateChanged:)
     name:        MPMusicPlayerControllerPlaybackStateDidChangeNotification
     object:      self.player];
    
    [notificationCenter addObserver:self 
                           selector:@selector(volumeChangedHardware:) 
                               name:@"AVSystemController_SystemVolumeDidChangeNotification" 
                             object:nil]; 
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.infoLabel.text = @"...";
	self.textFieldArtist.delegate = self;
    self.textFieldArtist.enablesReturnKeyAutomatically = YES;
    self.player = [MPMusicPlayerController applicationMusicPlayer];
    
    [self setNotifications];
    
    [self.player beginGeneratingPlaybackNotifications];
    
    [self.player setShuffleMode:MPMusicShuffleModeOff];
    self.player.repeatMode = MPMusicRepeatModeNone;
    
    self.sliderVolume.value = self.player.volume;
    
    
}
- (void)viewDidUnload
{
    [self.player stop];
    [self.player setQueueWithItemCollection:nil];
    self.infoCenter = nil;
    [[NSNotificationCenter defaultCenter]
     removeObserver: self
     name:           MPMusicPlayerControllerNowPlayingItemDidChangeNotification
     object:         self.player];
    
    [[NSNotificationCenter defaultCenter]
     removeObserver: self
     name:           MPMusicPlayerControllerPlaybackStateDidChangeNotification
     object:         self.player];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"AVSystemController_SystemVolumeDidChangeNotification"  object:nil];
    
    [self.player endGeneratingPlaybackNotifications];
    self.myCollection = nil;
    self.player = nil;
    [self setQueueButton:nil];
    [self setPrevButton:nil];
    [self setPlayButton:nil];
    [self setNextButton:nil];
    [self setSliderVolume:nil];
    [self setInfoLabel:nil];
    [self setTextFieldArtist:nil];
    [super viewDidUnload];
}
-(void)mediaPickerDidCancel:(MPMediaPickerController *)mediaPicker
{
    [self dismissModalViewControllerAnimated:YES];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}
-(void)updateQueueWithMediaItemCollection:(MPMediaItemCollection *)collection
{
    if (collection) 
    {
        if (self.myCollection == nil) 
        {
            self.myCollection = collection;
            [self.player setQueueWithItemCollection: self.myCollection];
            [self.player play];
        }
        else 
        {
            BOOL wasPlaying = NO;
            if (self.player.playbackState == MPMusicPlaybackStatePlaying) {
                wasPlaying = YES;
            }
            
            MPMediaItem *nowPlayingItem        = self.player.nowPlayingItem;
            NSTimeInterval currentPlaybackTime = self.player.currentPlaybackTime;
          
            NSMutableArray *combinedMediaItems =
            [[self.myCollection items] mutableCopy];
            NSArray *newMediaItems = [collection items];
            [combinedMediaItems addObjectsFromArray: newMediaItems];
            
            [self setMyCollection:
             [MPMediaItemCollection collectionWithItems:
              (NSArray *) combinedMediaItems]];
            
            [self.player setQueueWithItemCollection:self.myCollection];
            
            self.player.nowPlayingItem      = nowPlayingItem;
            self.player.currentPlaybackTime = currentPlaybackTime;
            
            if (wasPlaying) 
            {
                [self.player play];
            }
        }
    }
}
-(void)queryPressed:(id)sender
{
    NSString *artist = self.textFieldArtist.text;
    if (artist != nil && artist != @"")
    {
        MPMediaPropertyPredicate *artistPredicate = [MPMediaPropertyPredicate predicateWithValue:artist forProperty:MPMediaItemPropertyArtist comparisonType:MPMediaPredicateComparisonContains];
        MPMediaQuery *query = [[MPMediaQuery alloc] init];
        [query addFilterPredicate:artistPredicate];
        
        [query setGroupingType: MPMediaGroupingAlbum];
        
        NSArray *albums = [query collections];
        for (MPMediaItemCollection *album in albums) 
        {
            MPMediaItem *representativeItem = [album representativeItem];
            NSString *albumName = [representativeItem valueForProperty: MPMediaItemPropertyAlbumTitle];
            NSLog (@"%@", albumName);
        }
        
        NSArray *result = [query items];
        if ([result count] > 0)
        {
            [self updateQueueWithMediaItemCollection:[MPMediaItemCollection collectionWithItems:result]];
        }
        else
            self.infoLabel.text = @"Artist Not Found.";
    }
}
-(void)mediaPicker:(MPMediaPickerController *)mediaPicker didPickMediaItems:(MPMediaItemCollection *)mediaItemCollection
{
    [self updateQueueWithMediaItemCollection:mediaItemCollection];
    [self dismissModalViewControllerAnimated:YES];
}
-(void)queuePressed:(id)sender
{
    MPMediaPickerController *picker = [[MPMediaPickerController alloc] initWithMediaTypes:MPMediaTypeMusic];
    picker.delegate = self;
    picker.allowsPickingMultipleItems = YES;
    picker.prompt =
    NSLocalizedString (@"Add songs to play",
                       "Prompt in media item picker");
    [self presentModalViewController:picker animated:YES];
}

-(void)prevPressed:(id)sender
{
    if ([self.player currentPlaybackTime] > 5.0)
    {
        [self.player skipToBeginning];   
    }
    else
    {
        [self.player skipToPreviousItem];
    }
}
-(void)volumeChanged:(id)sender
{
    if (self.player.volume != self.sliderVolume.value)
    {
        self.sliderVolume.value = self.player.volume;
    }
}
-(void)playPressed:(id)sender
{
    if ((myCollection != nil) && (self.player.playbackState != MPMusicPlaybackStatePlaying))
    {
        [self.player play];
        [self.playButton setTitle:@"Pause" forState:UIControlStateNormal];
    }
    else if (self.player.playbackState == MPMusicPlaybackStatePlaying)
    {
        [self.player pause];
        [self.playButton setTitle:@"Play" forState:UIControlStateNormal];
    }
}
-(void)nextPressed:(id)sender
{
        [self.player skipToNextItem];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
