//
//  MainViewController.h
//  MPMediaPickerController Test

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>

@interface MainViewController : UIViewController <MPMediaPickerControllerDelegate, UITextFieldDelegate>{
    UIButton *queueButton;
    UIButton *prevButton;
    UIButton *playButton;
    UIButton *nextButton;
    UITextField *textFieldArtist;
    UISlider *sliderVolume;
    UILabel *infoLabel;
    MPMediaItemCollection *myCollection;
    
}

@property (strong, nonatomic) IBOutlet UIButton *queueButton;
@property (strong, nonatomic) IBOutlet UIButton *prevButton;
@property (strong, nonatomic) IBOutlet UIButton *playButton;
@property (strong, nonatomic) IBOutlet UIButton *nextButton;

@property (strong, nonatomic) IBOutlet UISlider *sliderVolume;
@property (strong, nonatomic) IBOutlet UILabel *infoLabel;

@property (strong, nonatomic) MPMediaItemCollection *myCollection;

@property (strong, nonatomic) MPMusicPlayerController *player;
@property (strong, nonatomic) MPNowPlayingInfoCenter *infoCenter;

@property (strong, nonatomic) IBOutlet UITextField *textFieldArtist;
-(IBAction)queryPressed:(id)sender;

-(IBAction)queuePressed:(id)sender;
-(IBAction)prevPressed:(id)sender;
-(IBAction)playPressed:(id)sender;
-(IBAction)nextPressed:(id)sender;

-(IBAction)volumeChanged:(id)sender;
@end
