//
//  RecordingViewController.h
//  Chapter7Recipe2

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface RecordingViewController : UIViewController <AVAudioPlayerDelegate>
{
    NSURL *url;
}
@property (strong, nonatomic) IBOutlet UIButton *recordButton;
@property (strong, nonatomic) IBOutlet UIButton *playButton;
@property (strong, nonatomic) IBOutlet UILabel *peakLevel;
@property (strong, nonatomic) IBOutlet UILabel *averageLevel;

- (IBAction)recordPressed:(id)sender;
- (IBAction)playPressed:(id)sender;

@property (strong, nonatomic) AVAudioRecorder *audioRecorder;
@property (strong, nonatomic) AVAudioPlayer *player;

@end
