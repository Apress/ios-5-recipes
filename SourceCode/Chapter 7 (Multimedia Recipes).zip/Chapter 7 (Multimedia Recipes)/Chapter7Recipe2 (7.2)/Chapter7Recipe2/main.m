//
//  main.m
//  Chapter7Recipe2

#import <UIKit/UIKit.h>

#import "RecordingAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RecordingAppDelegate class]));
    }
}
