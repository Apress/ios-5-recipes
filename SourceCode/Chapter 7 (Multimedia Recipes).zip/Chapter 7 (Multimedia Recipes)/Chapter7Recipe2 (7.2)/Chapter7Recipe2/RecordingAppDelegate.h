//
//  RecordingAppDelegate.h
//  Chapter7Recipe2

#import <UIKit/UIKit.h>

@class RecordingViewController;

@interface RecordingAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) RecordingViewController *viewController;

@end
