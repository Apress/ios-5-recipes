//
//  RecordingViewController.m
//  Chapter7Recipe2

#import "RecordingViewController.h"

@implementation RecordingViewController
@synthesize recordButton;
@synthesize playButton;
@synthesize peakLevel;
@synthesize averageLevel;

@synthesize audioRecorder, player;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)recordPressed:(id)sender
{
    if ([self.audioRecorder isRecording])
    {
        [self.audioRecorder stop];
        [self.recordButton setTitle:@"Record" forState:UIControlStateNormal];
    }
    else
    {
        [self.audioRecorder record];
        [self.recordButton setTitle:@"Stop" forState:UIControlStateNormal];
    }
}
-(void)audioPlayerDidFinishPlaying:(AVAudioPlayer *)player successfully:(BOOL)flag
{
    [self.playButton setTitle:@"Play" forState:UIControlStateNormal];
}
-(void)playPressed:(id)sender
{
    NSFileManager *manager = [[NSFileManager alloc] init];
    NSString *outputPath = [[NSString alloc] initWithFormat:@"%@%@", NSTemporaryDirectory(), @"recording.wav"];
    if (![self.player isPlaying])
    {
        if ([manager fileExistsAtPath:outputPath])
        {
            self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:url error:nil];
            [self.player play];
            [self.playButton setTitle:@"Pause" forState:UIControlStateNormal];
        }
    }
    else
    {
        [self.player pause];
        [self.playButton setTitle:@"Play" forState:UIControlStateNormal];
    }
}
-(void)updateLabels
{
    [self.audioRecorder updateMeters];
    self.averageLevel.text = [NSString stringWithFormat:@"%f", [self.audioRecorder averagePowerForChannel:0]];
    self.peakLevel.text = [NSString stringWithFormat:@"%f", [self.audioRecorder peakPowerForChannel:0]];
}
- (NSURL *) tempFileURL
{
    NSString *outputPath = [[NSString alloc] initWithFormat:@"%@%@", NSTemporaryDirectory(), @"recording.wav"];
    NSURL *outputURL = [[NSURL alloc] initFileURLWithPath:outputPath];
    NSFileManager *manager = [[NSFileManager alloc] init];
    if ([manager fileExistsAtPath:outputPath])
    {
        [manager removeItemAtPath:outputPath error:nil];
    }
    return outputURL;
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    url = [self tempFileURL];
    self.audioRecorder = [[AVAudioRecorder alloc] initWithURL:url settings:nil error:nil];
    self.audioRecorder.meteringEnabled = YES;
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(updateLabels) userInfo:nil repeats:YES];
    [timer fire];
    self.player.delegate = self;
    [self.audioRecorder prepareToRecord];
}

- (void)viewDidUnload
{
    self.audioRecorder = nil;
    self.player = nil;
    [self setRecordButton:nil];
    [self setPlayButton:nil];
    [self setPeakLevel:nil];
    [self setAverageLevel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
