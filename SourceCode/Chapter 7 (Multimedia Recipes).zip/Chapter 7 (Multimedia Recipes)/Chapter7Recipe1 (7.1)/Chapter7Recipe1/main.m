//
//  main.m
//  Chapter7Recipe1

#import <UIKit/UIKit.h>

#import "PlayerAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PlayerAppDelegate class]));
    }
}
