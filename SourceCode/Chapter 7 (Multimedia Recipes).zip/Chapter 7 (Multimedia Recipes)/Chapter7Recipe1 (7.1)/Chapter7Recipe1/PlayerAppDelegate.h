//
//  PlayerAppDelegate.h
//  Chapter7Recipe1

#import <UIKit/UIKit.h>

@class PlayerViewController;

@interface PlayerAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) PlayerViewController *viewController;

@end
