//
//  PlayerViewController.m
//  Chapter7Recipe1

#import "PlayerViewController.h"

@implementation PlayerViewController
@synthesize sliderRate;
@synthesize sliderPan;
@synthesize sliderVolume;
@synthesize vibrateButton;
@synthesize playButton;
@synthesize pauseButton;
@synthesize averageLabel;
@synthesize peakLabel;

@synthesize player;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(void)audioPlayerBeginInterruption:(AVAudioPlayer *)player
{
    [self.player pause];
}
-(void)audioPlayerEndInterruption:(AVAudioPlayer *)player
{
    [self.player play];
}
-(void)volumeSliderChanged:(UISlider *)sender
{
    self.player.volume = sender.value;
}
-(void)panSliderChanged:(UISlider *)sender
{
    self.player.pan = sender.value;
}
-(void)rateSliderChanged:(UISlider *)sender
{
    self.player.rate = sender.value;
}
-(void)vibratePressed:(id)sender
{
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
}
-(void)playPressed:(id)sender
{
    [self.player play];
}
-(void)pausePressed:(id)sender
{
    [self.player pause];
}
-(void)updateLabels
{
    [self.player updateMeters];
    self.averageLabel.text = [NSString stringWithFormat:@"%f", [self.player averagePowerForChannel:0]];
    self.peakLabel.text = [NSString stringWithFormat:@"%f", [self.player peakPowerForChannel:0]];
}
#pragma mark - View lifecycle
-(void)audioPlayerDecodeErrorDidOccur:(AVAudioPlayer *)player error:(NSError *)error
{
    NSLog(@"Error playing file: %@", [error localizedDescription]);
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString *fileName = @"systemCheck";  ///Change this line to the name of your sound file. You will need to import your own file.
    NSString *fileType = @"mp3";
    NSString *soundFilePath = [[NSBundle mainBundle] pathForResource:fileName ofType:fileType];
    NSURL *soundFileURL = [NSURL fileURLWithPath:soundFilePath];
    
    NSError *error;
    self.player = [[AVAudioPlayer alloc] initWithContentsOfURL:soundFileURL error:&error];
    self.player.enableRate = YES; //Allows us to change the playback rate.
    self.player.meteringEnabled = YES; //Allows us to monitor levels
    self.player.delegate = self;
    self.sliderVolume.value = self.player.volume;
    self.sliderRate.value = self.player.rate;
    self.sliderPan.value = self.player.pan;
    
    [self.player prepareToPlay]; //Preload audio to decrease lag
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(updateLabels) userInfo:nil repeats:YES];
    
    [timer fire];
}

- (void)viewDidUnload
{
    self.player.delegate = nil;
    self.player = nil;
    [self setSliderRate:nil];
    [self setSliderPan:nil];
    [self setSliderVolume:nil];
    [self setVibrateButton:nil];
    [self setPlayButton:nil];
    [self setPauseButton:nil];
    [self setAverageLabel:nil];
    [self setPeakLabel:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
