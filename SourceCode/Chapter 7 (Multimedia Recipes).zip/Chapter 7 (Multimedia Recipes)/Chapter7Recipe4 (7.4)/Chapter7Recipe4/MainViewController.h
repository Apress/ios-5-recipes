//
//  MainViewController.h
//  Chapter7Recipe4


#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <AVFoundation/AVFoundation.h>

@interface MainViewController : UIViewController <UITextFieldDelegate, AVAudioSessionDelegate, MPMediaPickerControllerDelegate>{
    UIButton *queryButton;
    UIButton *nextButton;
    UIButton *prevButton;
    UIButton *playButton;
    
    UILabel *infoLabel;
    UIImageView *artworkImageView;
    UIButton *libraryButton;
}
@property (strong, nonatomic) IBOutlet UILabel *infoLabel;
@property (strong, nonatomic) IBOutlet UIImageView *artworkImageView;
@property (strong, nonatomic) IBOutlet UIButton *libraryButton;

@property (strong, nonatomic) IBOutlet UITextField *textFieldSong;
@property (strong, nonatomic) IBOutlet UIButton *queryButton;
-(IBAction)queryPressed:(id)sender;
-(IBAction)nextPressed:(id)sender;
-(IBAction)prevPressed:(id)sender;
-(IBAction)playPressed:(id)sender;
-(IBAction)libraryPressed:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *nextButton;
@property (strong, nonatomic) IBOutlet UIButton *prevButton;
@property (strong, nonatomic) IBOutlet UIButton *playButton;

@property (nonatomic, strong) AVQueuePlayer *player;
@property (nonatomic, strong) AVAudioSession *session;

@property (nonatomic, strong) NSMutableArray *playlist;
@property (nonatomic, strong) NSMutableArray *myCollection;
@property (nonatomic) NSUInteger currentIndex;

@end
