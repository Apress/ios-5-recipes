//
//  MainViewController.m
//  Chapter7Recipe4

#import "MainViewController.h"

@implementation MainViewController
@synthesize nextButton;
@synthesize prevButton;
@synthesize playButton;
@synthesize infoLabel;
@synthesize artworkImageView;
@synthesize libraryButton;
@synthesize textFieldSong;
@synthesize queryButton;
@synthesize player, session;
@synthesize playlist, currentIndex, myCollection;

-(NSMutableArray *)playlist
{
    if (!playlist)
    {
        playlist = [[NSMutableArray alloc] initWithCapacity:5];
    }
    return playlist;
}
-(NSUInteger)currentIndex
{
    currentIndex = [self.playlist indexOfObject:self.player.currentItem];
    return currentIndex;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
#pragma mark - View lifecycle
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}
- (void) remoteControlReceivedWithEvent: (UIEvent *) receivedEvent {
    if (receivedEvent.type == UIEventTypeRemoteControl) {
        
        switch (receivedEvent.subtype) {
                
            case UIEventSubtypeRemoteControlTogglePlayPause:
                [self playPressed:nil];
                break;
                
            case UIEventSubtypeRemoteControlPreviousTrack:
                [self prevPressed:nil];
                break;
                
            case UIEventSubtypeRemoteControlNextTrack:
                [self nextPressed:nil];
                break;
                
            default:
                break;
        }
    }
}
-(void)updateNowPlaying
{
    if (self.player.currentItem != nil)
    {
        MPMediaItem *nowPlaying = [self.myCollection objectAtIndex:self.currentIndex];
//        NSLog(@"%@", [nowPlaying valueForProperty:MPMediaItemPropertyTitle]);
        
        self.infoLabel.text = [NSString stringWithFormat:@"%@ - %@", [nowPlaying valueForProperty:MPMediaItemPropertyTitle],  [nowPlaying valueForProperty:MPMediaItemPropertyArtist]];
        
        UIImage *artwork = [[nowPlaying valueForProperty:MPMediaItemPropertyArtwork] imageWithSize:self.artworkImageView.frame.size];
        if (artwork)
        {
            self.artworkImageView.image = artwork;
        }
        else
        {
            self.artworkImageView.image = nil;
        }
        if ([MPNowPlayingInfoCenter class])  
        {
            NSString *title = [nowPlaying valueForProperty:MPMediaItemPropertyTitle];
            NSString *artist = [nowPlaying valueForProperty:MPMediaItemPropertyArtist];
            NSDictionary *currentlyPlayingTrackInfo = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:title, artist, nil] forKeys:[NSArray arrayWithObjects:MPMediaItemPropertyTitle, MPMediaItemPropertyArtist, nil]];
            [MPNowPlayingInfoCenter defaultCenter].nowPlayingInfo = currentlyPlayingTrackInfo;
        }
    }
    else
    {
        self.infoLabel.text = @"...";
        [self.playButton setTitle:@"Play" forState:UIControlStateNormal];
        self.artworkImageView.image = nil;
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.session = [AVAudioSession sharedInstance];
    self.session.delegate = self;
    [self.session setCategory:AVAudioSessionCategoryPlayback error:nil];
    [self.session setActive:YES error:nil];
    
    self.textFieldSong.delegate = self;
    [self.playButton setTitle:@"Play" forState:UIControlStateNormal];
}
-(void)updatePlaylistWithArray:(NSArray *)collection
{
    if (([self.playlist count] == 0) || (self.player.currentItem == nil))
    {
        [self.myCollection removeAllObjects];
        self.playlist = [NSMutableArray arrayWithArray:collection];
        self.player = [[AVQueuePlayer alloc] initWithItems:self.playlist];
        [self.player play];
    }
    else
    {
        AVPlayerItem *currentItem = [self.playlist lastObject];
        for (AVPlayerItem *item in collection)
        {
            if ([self.player canInsertItem:item afterItem:currentItem])
            {
                [self.player insertItem:item afterItem:currentItem];
                currentItem = item;
            }
        }
        [self.playlist addObjectsFromArray:collection];
    }
}
-(void)updateMyCollectionWithArray:(NSArray *)mediaItems
{
    if ([self.myCollection count] == 0)
    {
        self.myCollection = [NSMutableArray arrayWithArray:mediaItems];
    }
    else
    {
        [self.myCollection addObjectsFromArray:mediaItems];
    }
}
- (void)playerItemDidReachEnd:(NSNotification *)notification
{
    [self performSelector:@selector(updateNowPlaying) withObject:nil afterDelay:0.5];
}
-(NSArray *)AVPlayerItemsFromArray:(NSArray *)items
{
    NSMutableArray *array = [[NSMutableArray alloc] initWithCapacity:[items count]];
    NSURL *url;
    for (MPMediaItem *current in items)
    {
        url = [current valueForProperty:MPMediaItemPropertyAssetURL];
        AVPlayerItem *playerItem = [AVPlayerItem playerItemWithURL:url];
        
        [[NSNotificationCenter defaultCenter]
         addObserver:self
         selector:@selector(playerItemDidReachEnd:)
         name:AVPlayerItemDidPlayToEndTimeNotification
         object:playerItem];
        
        if (playerItem != nil)
            [array addObject:playerItem];
    }
    return array;
}
-(void)mediaPickerDidCancel:(MPMediaPickerController *)mediaPicker
{
    [self dismissModalViewControllerAnimated:YES];
}
-(void)libraryPressed:(id)sender
{
    MPMediaPickerController *picker = [[MPMediaPickerController alloc] initWithMediaTypes:MPMediaTypeMusic];
    picker.delegate = self;
    picker.allowsPickingMultipleItems = YES;
    picker.prompt = @"Choose Some Music!";
    [self presentModalViewController:picker animated:YES];
}
-(void)prevPressed:(id)sender
{
    if (CMTimeCompare(self.player.currentTime, CMTimeMake(5.0, 1)) > 0)
    {
        [self.player seekToTime:kCMTimeZero];
    }
    else
    {
        [self.player pause];
        
        AVPlayerItem *current = self.player.currentItem;
        if (current != [self.playlist objectAtIndex:0])
        {
            AVPlayerItem *previous = [self.playlist objectAtIndex:[self.playlist indexOfObject:current]-1];
            if ([self.player canInsertItem:previous afterItem:current])
            {
                [current seekToTime:kCMTimeZero];
                [previous seekToTime:kCMTimeZero];
                
                [self.player insertItem:previous afterItem:current];
                [self.player advanceToNextItem];
                [self.player removeItem:current];
                [self.player insertItem:current afterItem:previous];
            }
            else
            {
                NSLog(@"Error: Could not insert");
            }
        }
        else
        {
            [self.player seekToTime:kCMTimeZero];
        }
        
        [self.player play];
    }
    [self updateNowPlaying];
}
-(void)mediaPicker:(MPMediaPickerController *)mediaPicker didPickMediaItems:(MPMediaItemCollection *)mediaItemCollection
{
    [self updatePlaylistWithArray:[self AVPlayerItemsFromArray:[mediaItemCollection items]]];
    [self updateMyCollectionWithArray:[mediaItemCollection items]];
    [self.playButton setTitle:@"Pause" forState:UIControlStateNormal];
    [self updateNowPlaying];
     
    [self dismissModalViewControllerAnimated:YES];
}
-(void)queryPressed:(id)sender
{
    MPMediaQuery *query = [[MPMediaQuery alloc] init];
    NSString *title = self.textFieldSong.text;
    MPMediaPropertyPredicate *songPredicate = [MPMediaPropertyPredicate predicateWithValue:title forProperty:MPMediaItemPropertyTitle comparisonType:MPMediaPredicateComparisonContains];
    [query addFilterPredicate:songPredicate];
    
    [self updatePlaylistWithArray:[self AVPlayerItemsFromArray:[query items]]];
    [self updateMyCollectionWithArray:[query items]];
    
    [self.playButton setTitle:@"Pause" forState:UIControlStateNormal];
    
    [self updateNowPlaying];
    if ([self.textFieldSong isFirstResponder])
        [self.textFieldSong resignFirstResponder];
}
-(void)playPressed:(id)sender
{
    if (self.playlist.count > 0)
    {
        if ([[self.playButton titleForState:UIControlStateNormal] isEqualToString:@"Play"])
        {
            [self.player play];
            [self.playButton setTitle:@"Pause" forState:UIControlStateNormal];
        }
        else
        {
            [self.player pause];
            //Scrub back half a second to give the user a little lead-in when they resume playing
            [self.player seekToTime:CMTimeSubtract(self.player.currentTime, CMTimeMakeWithSeconds(0.5, 1.0)) completionHandler:^(BOOL finished)
             {
                 [self.playButton setTitle:@"Play" forState:UIControlStateNormal];
             }];
        }
     [self updateNowPlaying];
    }
}
-(void)nextPressed:(id)sender
{
    [self.player advanceToNextItem];
    if (self.player.currentItem == nil)
    {
        [self.playlist removeAllObjects];
        [self.myCollection removeAllObjects];
    }
    [self updateNowPlaying];
}
- (void)viewDidUnload
{
    for (AVPlayerItem *playerItem in self.playlist)
    {
        [[NSNotificationCenter defaultCenter] removeObserver:self name:AVPlayerItemDidPlayToEndTimeNotification object:playerItem];
    }
    
    [self.session setActive:NO error:nil];
    self.player = nil;
    [self setTextFieldSong:nil];
    [self setQueryButton:nil];
    [self setNextButton:nil];
    [self setPrevButton:nil];
    [self setPlayButton:nil];
    [self setInfoLabel:nil];
    [self setArtworkImageView:nil];
    [self setLibraryButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated 
{
    [super viewDidAppear:animated];
    [[UIApplication sharedApplication] beginReceivingRemoteControlEvents];
    [self becomeFirstResponder];
}
-(BOOL)canBecomeFirstResponder
{
    return YES;
}
- (void)viewWillDisappear:(BOOL)animated 
{
    [[UIApplication sharedApplication] endReceivingRemoteControlEvents];
    [self resignFirstResponder];
    [super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
