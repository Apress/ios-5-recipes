//
//  MainViewController.m
//  Tweeter

#import "MainViewController.h"

@implementation MainViewController
@synthesize simpleTweetButton;

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
-(BOOL)checkCanTweet
{
    if ([TWTweetComposeViewController canSendTweet])
    {
        self.simpleTweetButton.enabled = YES;
        self.simpleTweetButton.alpha = 1.0;
        return YES;
    }
    else
    {
        self.simpleTweetButton.enabled = NO;
        self.simpleTweetButton.alpha = 0.6;
        return NO;
    }
}
-(void)simpleTweetPressed:(id)sender
{
    if ([self checkCanTweet])
    {
        TWTweetComposeViewController *tweet = [[TWTweetComposeViewController alloc] init];
        [tweet setInitialText:@"Posting a simple Tweet from my app!"];
        [tweet setCompletionHandler:^(TWTweetComposeViewControllerResult result) 
        {
           if (result == TWTweetComposeViewControllerResultDone)
           {
               NSLog(@"Tweet Successfully Sent");
           }
           else
           {
               NSLog(@"Tweet Cancelled");
           }
           [self dismissModalViewControllerAnimated:YES];
        }];
        [self presentModalViewController:tweet animated:YES];
    }
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self checkCanTweet];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(checkCanTweet) name:ACAccountStoreDidChangeNotification object:nil];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [self setSimpleTweetButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self checkCanTweet];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
