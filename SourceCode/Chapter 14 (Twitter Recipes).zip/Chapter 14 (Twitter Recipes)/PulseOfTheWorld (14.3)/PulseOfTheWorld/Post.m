//
//  Post.m
//  PulseOfTheWorld

#import "Post.h"

@implementation Post

@synthesize name, text, user, postData, screenName, retweetCount, userDescription, userImage;

-(Post *)initWithDictionary:(NSDictionary *)dictionary
{
    self = [super init];
    if (self)
    {
        self.postData = dictionary;
        self.user = [dictionary objectForKey:@"user"];
        self.text = [dictionary objectForKey:@"text"];
        self.retweetCount = [dictionary objectForKey:@"retweet_count"];
        self.name = [self.user objectForKey:@"name"];
        self.screenName = [self.user objectForKey:@"screen_name"];
        self.userDescription = [self.user objectForKey:@"description"];
        NSString *imageURLString = [self.user objectForKey:@"profile_image_url"];
        NSURL *imageURL = [NSURL URLWithString:imageURLString];
        NSData *imageData = [NSData dataWithContentsOfURL:imageURL];
        self.userImage = [UIImage imageWithData:imageData];
    }
    return self;
}

@end
