//
//  MainFirstViewController.h
//  PulseOfTheWorld

#import <UIKit/UIKit.h>
#import <Twitter/Twitter.h>
#import <Accounts/Accounts.h>
#import "Post.h"

@interface MainFirstViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
-(IBAction)publicPressed:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *tableViewPosts;

@property (strong, nonatomic) NSMutableArray *retrievedTweets;
@end
