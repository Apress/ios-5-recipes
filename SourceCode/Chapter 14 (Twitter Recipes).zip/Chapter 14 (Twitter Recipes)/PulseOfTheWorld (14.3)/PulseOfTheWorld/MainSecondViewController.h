//
//  MainSecondViewController.h
//  PulseOfTheWorld

#import <UIKit/UIKit.h>
#import <Twitter/Twitter.h>
#import <Accounts/Accounts.h>
#import "Post.h"

@interface MainSecondViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *tableViewPosts;
@property (strong, nonatomic) NSMutableArray *retrievedTweets;
-(IBAction)homePressed:(id)sender;
-(BOOL)checkCanTweet;
@end
