//
//  MainSecondViewController.m
//  PulseOfTheWorld

#import "MainSecondViewController.h"

@implementation MainSecondViewController
@synthesize tableViewPosts, retrievedTweets;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Home Timeline", @"Second");
        self.tabBarItem.image = [UIImage imageNamed:@"second"];
    }
    return self;
}
-(NSMutableArray *)retrievedTweets
{
    if (retrievedTweets == nil)
    {
        retrievedTweets = [NSMutableArray arrayWithCapacity:20];
    }
    return retrievedTweets;
}
-(BOOL)checkCanTweet
{
    if ([TWTweetComposeViewController canSendTweet])
    {
        return YES;
    }
    else
    {
        return NO;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.retrievedTweets count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) 
    {
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    Post *current = [self.retrievedTweets objectAtIndex:indexPath.row];
	cell.textLabel.text = current.text;
    cell.detailTextLabel.text = current.screenName;
    cell.imageView.image = current.userImage;
    
	return cell;
}
- (IBAction)homePressed:(id)sender 
{
    if ([self checkCanTweet])
    {
        ACAccountStore *accountStore = [[ACAccountStore alloc] init];
        ACAccountType *accountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
        
        [accountStore requestAccessToAccountsWithType:accountType withCompletionHandler:^(BOOL granted, NSError *error) 
        {
            if(granted) 
            {
                NSArray *accountsArray = [accountStore accountsWithAccountType:accountType];
                if ([accountsArray count] > 0) 
                {
                    [self.retrievedTweets removeAllObjects];

                    ACAccount *twitterAccount = [accountsArray objectAtIndex:0];
                    
                    TWRequest *postRequest = [[TWRequest alloc] initWithURL:[NSURL URLWithString:@"http://api.twitter.com/1/statuses/home_timeline.json"] parameters:nil requestMethod:TWRequestMethodGET];
                    [postRequest setAccount:twitterAccount];
                    
                    [postRequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) 
                     {                         
                         if ([urlResponse statusCode] == 200)
                         {
                             NSError *jsonParsingError;
                             NSArray *homeTimeline = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:&jsonParsingError];
                             for (NSDictionary *dict in homeTimeline)
                             {
                                 Post *current = [[Post alloc] initWithDictionary:dict];
                                 [self.retrievedTweets addObject:current];
                             }
                         }
                         else 
                         {
                             NSLog(@"%@", [NSString stringWithFormat:@"HTTP response status: %i\n", [urlResponse statusCode]]);
                         }
                         [self.tableViewPosts reloadData];
                     }];
                }
            }
            else
            {
                NSLog(@"Error, Twitter account access not granted.");
            }
        }];
    }
}							
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableViewPosts.delegate = self;
    self.tableViewPosts.dataSource = self;
}

- (void)viewDidUnload
{
    [self setTableViewPosts:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSLog(@"refreshing");
    [self homePressed:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
