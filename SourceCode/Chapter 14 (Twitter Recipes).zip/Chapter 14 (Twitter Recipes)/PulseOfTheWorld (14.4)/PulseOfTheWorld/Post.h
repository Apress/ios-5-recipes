//
//  Post.h
//  PulseOfTheWorld

#import <Foundation/Foundation.h>

@interface Post : NSObject

@property (nonatomic, strong) NSDictionary *postData;
@property (nonatomic, strong) NSDictionary *user;
@property (nonatomic, strong) NSString *text;
@property (nonatomic, strong) NSString *screenName;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *userDescription;
@property (nonatomic, strong) id retweetCount; //Could be NSString (100+) or NSNumber
@property (nonatomic, strong) UIImage *userImage;
-(Post *)initWithDictionary:(NSDictionary *)dictionary;
-(Post *)initWithSearchDictionary:(NSDictionary *)dictionary;
@end
