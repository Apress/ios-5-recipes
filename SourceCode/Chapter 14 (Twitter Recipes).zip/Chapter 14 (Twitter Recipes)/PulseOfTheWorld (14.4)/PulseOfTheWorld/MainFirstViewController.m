//
//  MainFirstViewController.m
//  PulseOfTheWorld

#import "MainFirstViewController.h"

@implementation MainFirstViewController
@synthesize tableViewPosts;
@synthesize retrievedTweets;

-(NSMutableArray *)retrievedTweets
{
    if (retrievedTweets == nil)
    {
        retrievedTweets = [NSMutableArray arrayWithCapacity:20];
    }
    return retrievedTweets;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Public Timeline", @"First");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.retrievedTweets count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) 
    {
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    Post *current = [self.retrievedTweets objectAtIndex:indexPath.row];
	cell.textLabel.text = current.text;
    cell.detailTextLabel.text = current.screenName;
    cell.imageView.image = current.userImage;

	return cell;
}						
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}
- (IBAction)publicPressed:(id)sender 
{
    TWRequest *postRequest = [[TWRequest alloc] initWithURL:[NSURL URLWithString:@"http://api.twitter.com/1/statuses/public_timeline.json"] parameters:nil requestMethod:TWRequestMethodGET];
    
    [postRequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) 
    {
        if ([urlResponse statusCode] == 200)
        {
            NSError *jsonParsingError;
            NSArray *publicTimeline = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:&jsonParsingError];
            for (NSDictionary *dict in publicTimeline)
            {
                Post *current = [[Post alloc] initWithDictionary:dict];
                [self.retrievedTweets addObject:current];
            }
        }
        else 
        {
           NSLog(@"%@", [NSString stringWithFormat:@"HTTP response status: %i\n", [urlResponse statusCode]]);
        }
        [self.tableViewPosts reloadData];
    }];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableViewPosts.delegate = self;
    self.tableViewPosts.dataSource = self;
}

- (void)viewDidUnload
{
    [self setTableViewPosts:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self publicPressed:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
