//
//  MainSearchViewController.h
//  PulseOfTheWorld

#import <UIKit/UIKit.h>
#import <Twitter/Twitter.h>
#import "Post.h"

@interface MainSearchViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tableViewPosts;
@property (strong, nonatomic) IBOutlet UISearchBar *searchBarPosts;

@property (strong, nonatomic) NSMutableArray *retrievedTweets;

@end
