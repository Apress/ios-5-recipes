//
//  MainSearchViewController.m
//  PulseOfTheWorld

#import "MainSearchViewController.h"

@implementation MainSearchViewController
@synthesize tableViewPosts;
@synthesize searchBarPosts;
@synthesize retrievedTweets;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Filtered Posts", @"First");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}
-(NSMutableArray *)retrievedTweets
{
    if (retrievedTweets == nil)
    {
        retrievedTweets = [NSMutableArray arrayWithCapacity:20];
    }
    return retrievedTweets;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.retrievedTweets count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
	static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) 
    {
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
    Post *current = [self.retrievedTweets objectAtIndex:indexPath.row];
	cell.textLabel.text = current.text;
    cell.detailTextLabel.text = current.screenName;
    cell.imageView.image = current.userImage;
    
	return cell;
}	
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (IBAction)searchPressed:(NSString *)searchText 
{
    [self.retrievedTweets removeAllObjects];
    
    searchText = [searchText stringByAddingPercentEscapesUsingEncoding: NSUTF8StringEncoding];
    
    NSMutableString *mutableText = [[NSMutableString alloc] initWithString:searchText];
    [mutableText replaceOccurrencesOfString:@"@" withString:[NSString stringWithFormat:@"%%40"] options:NSLiteralSearch range:NSMakeRange(0, [mutableText length])];
    
//    NSLog(@"Searching: %@", mutableText);
    
    NSString *searchString = @"http://search.twitter.com/search.json?q=";
    searchString = [searchString stringByAppendingString:mutableText];
    NSURL *searchURL = [NSURL URLWithString:searchString];
    
    TWRequest *postRequest = [[TWRequest alloc] initWithURL:searchURL parameters:nil requestMethod:TWRequestMethodGET];
    
    [postRequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error) 
     {
         if ([urlResponse statusCode] == 200)
         {
             NSError *jsonParsingError;
             NSDictionary *searchTimeline = [NSJSONSerialization JSONObjectWithData:responseData options:0 error:&jsonParsingError];
             NSArray *searchResults = [searchTimeline objectForKey:@"results"];
             for (NSDictionary *dict in searchResults)
             {
                 Post *current = [[Post alloc] initWithSearchDictionary:dict];
                 [self.retrievedTweets addObject:current];
             }
//             NSLog(@"Data Retrieved: HTTP response code %i", [urlResponse statusCode]);
         }
         else 
         {
             NSLog(@"%@", [NSString stringWithFormat:@"HTTP response status: %i\n", [urlResponse statusCode]]);
         }
         [self.tableViewPosts reloadData];
         [self.tableViewPosts reloadInputViews];
     }];
}
-(BOOL)searchBar:(UISearchBar *)searchBar shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"])
    {
        [searchBar resignFirstResponder];
        [self searchPressed:searchBar.text];
        return NO;
    }
    return YES;
}
#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.tableViewPosts.delegate = self;
    self.tableViewPosts.dataSource = self;
    self.searchBarPosts.delegate = self;
}

- (void)viewDidUnload
{
    [self setTableViewPosts:nil];
    [self setSearchBarPosts:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
