//
//  MainViewController.h
//  Tweeter

#import <UIKit/UIKit.h>
#import <Twitter/Twitter.h>
#import <Accounts/Accounts.h>

@interface MainViewController : UIViewController

@property (strong, nonatomic) IBOutlet UIButton *postTweetButton;
@property (strong, nonatomic) IBOutlet UIButton *simpleTweetButton;

-(IBAction)simpleTweetPressed:(id)sender;
-(IBAction)postTweetPressed:(id)sender;
@end
