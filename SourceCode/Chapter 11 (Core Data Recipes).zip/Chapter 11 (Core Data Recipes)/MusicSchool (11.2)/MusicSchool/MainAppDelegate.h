//
//  MainAppDelegate.h
//  MusicSchool

#import <UIKit/UIKit.h>
#import "MainTableViewController.h"

@interface MainAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

@property (strong, nonatomic) MainTableViewController *teacherTable;
@property (strong, nonatomic) MainTableViewController *studentTable;
@property (strong, nonatomic) MainTableViewController *instrumentTable;

@property (strong, nonatomic) UINavigationController *teacherNavcon;
@property (strong, nonatomic) UINavigationController *studentNavcon;
@property (strong, nonatomic) UINavigationController *instrumentNavcon;

@property (strong, nonatomic) UITabBarController *tabBarController;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

@end
