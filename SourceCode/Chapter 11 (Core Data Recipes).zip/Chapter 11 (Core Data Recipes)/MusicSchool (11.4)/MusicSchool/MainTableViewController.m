//
//  MainTableViewController.m
//  MusicSchool

#import "MainTableViewController.h"

@implementation MainTableViewController
@synthesize tableViewMain, entityDescription, fetchedResultsController, managedObjectContext;
@synthesize predicate, delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void)MainTableViewController:(MainTableViewController *)mainTableVC didSelectInstrument:(NSManagedObject *)instrument
{
    [selectedTeacher addInstrumentsObject:instrument];
    NSError *saveError;
    BOOL success = [self.managedObjectContext save:&saveError];
    if (!success)
    {
        NSLog(@"%@", [saveError localizedFailureReason]);
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableViewMain deselectRowAtIndexPath:indexPath animated:YES];
    if ([self.entityDescription.name isEqualToString:@"Teacher"])
    {
        selectedTeacher = [self.fetchedResultsController objectAtIndexPath:indexPath];
        MainTableViewController *selectInstrument = [[MainTableViewController alloc] init];
        selectInstrument.entityDescription = [NSEntityDescription entityForName:@"Instrument" inManagedObjectContext:self.managedObjectContext];
        selectInstrument.managedObjectContext = self.managedObjectContext;
        selectInstrument.delegate = self;
        [self.navigationController pushViewController:selectInstrument animated:YES];
    }
    else if ([self.entityDescription.name isEqualToString:@"Instrument"] && (self.delegate != nil))
    {
        [self.delegate MainTableViewController:self didSelectInstrument:[self.fetchedResultsController objectAtIndexPath:indexPath]];
        [self.navigationController popViewControllerAnimated:YES];
    }
}
-(void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
{
    if (![self.title isEqualToString:@"Filtered"])
    {
        MainTableViewController *filtered = [[MainTableViewController alloc] init];
        filtered.title = @"Filtered";
        filtered.managedObjectContext = self.managedObjectContext;
    
        if ([self.entityDescription.name isEqualToString:@"Teacher"])
        {
            filtered.entityDescription = [NSEntityDescription entityForName:@"Instrument" inManagedObjectContext:self.managedObjectContext];
            NSSet *instruments = [(Teacher *)[self.fetchedResultsController objectAtIndexPath:indexPath] instruments];
            filtered.predicate = [NSPredicate predicateWithFormat:@"self IN %@", instruments];
        }
        else if ([self.entityDescription.name isEqualToString:@"Student"])
        {
            filtered.entityDescription = self.entityDescription;
            filtered.predicate = [NSPredicate predicateWithFormat:@"age=%i", [[(Student *)[self.fetchedResultsController objectAtIndexPath: indexPath] age] intValue]];
        }
        else
        {
            filtered.entityDescription = self.entityDescription;
            filtered.predicate = [NSPredicate predicateWithFormat:@"family=%@", [(Instrument *)[self.fetchedResultsController objectAtIndexPath:indexPath]family]];
        }
    
        [self.navigationController pushViewController:filtered animated:YES];
    }
}
-(void)fetchResults
{
    NSFetchRequest *fetchRequest = [NSFetchRequest fetchRequestWithEntityName:self.entityDescription.name];
    NSString *cacheName = [self.entityDescription.name stringByAppendingString:@"Cache"];
    
    ////////////New Predicate code
    if (self.predicate != nil)
    {
        [fetchRequest setPredicate:self.predicate];
    }
    ////////////End of new code
    
    NSSortDescriptor *sortDescriptor = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES];
    [fetchRequest setSortDescriptors:[NSArray arrayWithObject:sortDescriptor]];
    
    self.fetchedResultsController = [[NSFetchedResultsController alloc] initWithFetchRequest:fetchRequest managedObjectContext:self.managedObjectContext sectionNameKeyPath:nil cacheName:cacheName];
    
    BOOL success;
    NSError *error;
    success = [self.fetchedResultsController performFetch:&error];
    if (!success)
    {
        NSLog(@"%@", [error localizedDescription]);
    }
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        NSManagedObject *deleted = [self.fetchedResultsController objectAtIndexPath:indexPath];
        [self.managedObjectContext deleteObject:deleted];
        NSError *error;
        BOOL success = [self.managedObjectContext save:&error];
        if (!success)
        {
            NSLog(@"%@", [error localizedDescription]);
        }
        [self fetchResults];
        [self.tableViewMain deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationRight];
    }
}
-(void)add
{
    NSManagedObject *add = [[NSManagedObject alloc] initWithEntity:self.entityDescription insertIntoManagedObjectContext:self.managedObjectContext];
    if ([self.entityDescription.name isEqualToString:@"Teacher"])
    {
        Teacher *teacher = (Teacher *)add;
        teacher.name = @"William";
        teacher.age = [NSNumber numberWithInt:42];
    }
    else if ([self.entityDescription.name isEqualToString:@"Instrument"])
    {
        Instrument *instrument = (Instrument *)add;
        instrument.name = @"Trumpet";
        instrument.family = @"Brass";
    }
    else
    {
        Student *student = (Student *)add;
        student.name = @"Christopher";
        student.age = [NSNumber numberWithInt:20];
    }
    
    NSError *error;
    BOOL success = [self.managedObjectContext save:&error];
    if (!success)
    {
        NSLog(@"%@", [error localizedDescription]);
    }
    
    [self fetchResults];
    
    [self.tableViewMain reloadData];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDetailDisclosureButton;
        cell.textLabel.font = [UIFont systemFontOfSize:19.0];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12];
    }
    
    NSManagedObject *object = [self.fetchedResultsController objectAtIndexPath:indexPath];
    
    if ([object.entity.name isEqualToString:@"Instrument"])
    {
        Instrument *instrument = (Instrument *)object;
        cell.textLabel.text = instrument.name;
        cell.detailTextLabel.text = instrument.family;
    }
    else if ([object.entity.name isEqualToString:@"Student"])
    {
        Student *student = (Student *)object;
        cell.textLabel.text = student.name;
        cell.detailTextLabel.text = [student.age stringValue];
    }
    else
    {
        Teacher *teacher = (Teacher *)object;
        cell.textLabel.text = teacher.name;
        cell.detailTextLabel.text = [teacher.age stringValue];
    }
    
	return cell;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self.fetchedResultsController fetchedObjects] count]; 
}
- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableViewMain.delegate = self;
    self.tableViewMain.dataSource = self;
    
    UIBarButtonItem *addButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(add)];
    UIBarButtonItem *editButton = self.editButtonItem;
    self.navigationItem.rightBarButtonItems = [NSArray arrayWithObjects:addButton, editButton, nil];
    
    [self fetchResults];
    
}
-(void)setEditing:(BOOL)editing animated:(BOOL)animated
{
    [super setEditing:editing animated:animated];
    [self.tableViewMain setEditing:editing animated:animated];
}
- (void)viewDidUnload
{
    [self setDelegate:nil];
    [self setPredicate:nil];
    [self setManagedObjectContext:nil];
    [self setFetchedResultsController:nil];
    [self setEntityDescription:nil];
    [self setTableViewMain:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
