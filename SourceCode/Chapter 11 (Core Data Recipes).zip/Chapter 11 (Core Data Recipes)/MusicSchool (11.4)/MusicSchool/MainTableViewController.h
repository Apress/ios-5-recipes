//
//  MainTableViewController.h
//  MusicSchool

#import <UIKit/UIKit.h>
#import "Instrument.h"
#import "Student.h"
#import "Teacher.h"

@interface MainTableViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>{
    UITableView *tableViewMain;
    
    __strong Teacher *selectedTeacher;
}

@property (strong, nonatomic) IBOutlet UITableView *tableViewMain;

@property (nonatomic, strong) NSEntityDescription *entityDescription;
@property (nonatomic, strong) NSFetchedResultsController *fetchedResultsController;
@property (nonatomic, strong) NSManagedObjectContext *managedObjectContext;

@property (nonatomic, strong) NSPredicate *predicate;
@property (nonatomic, strong) MainTableViewController *delegate;

-(void)MainTableViewController:(MainTableViewController *)mainTableVC didSelectInstrument:(Instrument *)instrument;

@end
