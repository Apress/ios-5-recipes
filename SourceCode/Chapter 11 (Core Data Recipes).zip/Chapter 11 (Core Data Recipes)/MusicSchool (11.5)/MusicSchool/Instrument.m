//
//  Instrument.m
//  MusicSchool

#import "Instrument.h"
#import "Student.h"
#import "Teacher.h"


@implementation Instrument

@dynamic family;
@dynamic name;
@dynamic range;
@dynamic size;
@dynamic students;
@dynamic teachers;

@end
