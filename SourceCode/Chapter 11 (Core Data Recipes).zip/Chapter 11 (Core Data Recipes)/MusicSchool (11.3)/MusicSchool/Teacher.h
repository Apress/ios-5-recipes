//
//  Teacher.h
//  MusicSchool

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Teacher : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSNumber * age;
@property (nonatomic, retain) NSNumber * years;
@property (nonatomic, retain) NSString * language;
@property (nonatomic, retain) NSSet *students;
@property (nonatomic, retain) NSSet *instruments;
@end

@interface Teacher (CoreDataGeneratedAccessors)

- (void)addStudentsObject:(NSManagedObject *)value;
- (void)removeStudentsObject:(NSManagedObject *)value;
- (void)addStudents:(NSSet *)values;
- (void)removeStudents:(NSSet *)values;
- (void)addInstrumentsObject:(NSManagedObject *)value;
- (void)removeInstrumentsObject:(NSManagedObject *)value;
- (void)addInstruments:(NSSet *)values;
- (void)removeInstruments:(NSSet *)values;
@end
