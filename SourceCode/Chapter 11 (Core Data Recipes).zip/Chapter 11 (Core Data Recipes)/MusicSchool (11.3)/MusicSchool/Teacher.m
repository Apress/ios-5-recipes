//
//  Teacher.m
//  MusicSchool

#import "Teacher.h"


@implementation Teacher

@dynamic name;
@dynamic age;
@dynamic years;
@dynamic language;
@dynamic students;
@dynamic instruments;

@end
