//
//  Student.h
//  MusicSchool

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Teacher;

@interface Student : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSNumber * age;
@property (nonatomic, retain) NSString * language;
@property (nonatomic, retain) NSString * skill;
@property (nonatomic, retain) Teacher *teacher;
@property (nonatomic, retain) NSManagedObject *instrument;

@end
