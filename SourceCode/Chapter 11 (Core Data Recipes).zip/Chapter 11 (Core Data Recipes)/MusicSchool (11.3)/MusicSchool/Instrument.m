//
//  Instrument.m
//  MusicSchool

#import "Instrument.h"
#import "Student.h"
#import "Teacher.h"


@implementation Instrument

@dynamic name;
@dynamic family;
@dynamic students;
@dynamic teachers;

@end
