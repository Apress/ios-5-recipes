//
//  Student.m
//  MusicSchool

#import "Student.h"
#import "Teacher.h"


@implementation Student

@dynamic name;
@dynamic age;
@dynamic language;
@dynamic skill;
@dynamic teacher;
@dynamic instrument;

@end
