//
//  CountryInfoViewController.m
//  Countries

#import "CountryInfoViewController.h"

@implementation CountryInfoViewController
@synthesize nameLabel;
@synthesize imageViewFlag;
@synthesize textFieldCapital;
@synthesize textFieldMotto;
@synthesize currentCountry, delegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return NO;
}
#pragma mark - View lifecycle
-(void)populateViewWithCountry:(Country *)country
{
    self.currentCountry = country;
    
    self.imageViewFlag.image = country.flag;
    self.nameLabel.text = country.name;
    self.textFieldCapital.text = country.capital;
    self.textFieldMotto.text = country.motto;
}
-(void)revert
{
    [self populateViewWithCountry:self.currentCountry];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
        
    self.textFieldMotto.delegate = self;
    self.textFieldCapital.delegate = self;
    
    UIBarButtonItem *revertButton = [[UIBarButtonItem alloc] initWithTitle:@"Revert" style:UIBarButtonItemStyleBordered target:self action:@selector(revert)];
    self.navigationItem.rightBarButtonItems = [NSArray arrayWithObject:revertButton];
}
-(void)viewWillDisappear:(BOOL)animated
{
    self.currentCountry.capital = self.textFieldCapital.text;
    self.currentCountry.motto = self.textFieldMotto.text;
    [self.delegate countryInfoViewControllerDidFinish:self];
}
-(void)viewWillAppear:(BOOL)animated
{
    [self populateViewWithCountry:self.currentCountry];
}
- (void)viewDidUnload
{
    [self setDelegate:nil];
    [self setCurrentCountry:nil];
    [self setNameLabel:nil];
    [self setImageViewFlag:nil];
    [self setTextFieldCapital:nil];
    [self setTextFieldMotto:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
