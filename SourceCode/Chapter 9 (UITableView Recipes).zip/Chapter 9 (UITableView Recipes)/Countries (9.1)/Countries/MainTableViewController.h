//
//  MainTableViewController.h
//  Countries

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "Country.h"
#import "CountryInfoViewController.h"

@interface MainTableViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, CountryInfoDelegate>{
    UITableView *tableViewCountries;
    
    NSIndexPath *selectedIndexPath;
}

@property (strong, nonatomic) IBOutlet UITableView *tableViewCountries;

@property (strong, nonatomic) NSMutableArray *countries;

@end
