//
//  CountryInfoViewController.h
//  Countries

#import <UIKit/UIKit.h>
#import "Country.h"

@class CountryInfoViewController;
@protocol CountryInfoDelegate <NSObject>

-(void)countryInfoViewControllerDidFinish:(CountryInfoViewController *)countryVC;

@end

@interface CountryInfoViewController : UIViewController <UITextFieldDelegate>{
    UILabel *nameLabel;
    UIImageView *imageViewFlag;
    UITextField *textFieldCapital;
    UITextField *textFieldMotto;
}

@property (strong, nonatomic) IBOutlet UILabel *nameLabel;
@property (strong, nonatomic) IBOutlet UIImageView *imageViewFlag;
@property (strong, nonatomic) IBOutlet UITextField *textFieldCapital;
@property (strong, nonatomic) IBOutlet UITextField *textFieldMotto;

@property (strong, nonatomic) Country *currentCountry;
@property (strong, nonatomic) id <CountryInfoDelegate> delegate;

@end
