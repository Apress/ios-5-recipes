//
//  MainAppDelegate.h
//  Countries

#import <UIKit/UIKit.h>
#import "MainTableViewController.h"

@interface MainAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) UINavigationController *navcon;
@property (nonatomic, strong) MainTableViewController *tableVC;
@end
