//
//  Country.m
//  Countries

#import "Country.h"

@implementation Country

@synthesize name, capital, motto, flag;

@end
